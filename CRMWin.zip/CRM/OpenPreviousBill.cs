﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace CRM
{
    public partial class OpenPreviousBill : Form
    {
        public OpenPreviousBill()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text + ".html";
            try
            {
                Process.Start(filename);
            }
            catch (Exception ee)
            {
                MessageBox.Show("Sorry, Invoice could not be found.");
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string filename = textBox1.Text + ".html";
                try
                {
                    Process.Start(filename);
                }
                catch (Exception ee)
                {
                    MessageBox.Show("Sorry, Invoice could not be found.");
                }   
            }
        }
    }
}
