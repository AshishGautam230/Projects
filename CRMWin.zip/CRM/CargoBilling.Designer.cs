﻿namespace CRM
{
    partial class CargoBilling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CargoBilling));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtLisc = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtAdc = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtTransportation = new System.Windows.Forms.TextBox();
            this.txtDcc = new System.Windows.Forms.TextBox();
            this.txtCmcCha = new System.Windows.Forms.TextBox();
            this.txtFork = new System.Windows.Forms.TextBox();
            this.txtMarking = new System.Windows.Forms.TextBox();
            this.txtMisc = new System.Windows.Forms.TextBox();
            this.txtRepacking = new System.Windows.Forms.TextBox();
            this.txtDocumentation = new System.Windows.Forms.TextBox();
            this.txtCustomDuty = new System.Windows.Forms.TextBox();
            this.txtWtDiff = new System.Windows.Forms.TextBox();
            this.txtGsp = new System.Windows.Forms.TextBox();
            this.txtCha = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAgency = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtChargesAirlines = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtContainer = new System.Windows.Forms.TextBox();
            this.txtLoading = new System.Windows.Forms.TextBox();
            this.txtDOCharges = new System.Windows.Forms.TextBox();
            this.txtDamurrage = new System.Windows.Forms.TextBox();
            this.txtAAIWT = new System.Windows.Forms.TextBox();
            this.txtTR6 = new System.Windows.Forms.TextBox();
            this.txtBillLading = new System.Windows.Forms.TextBox();
            this.txtAirFreight = new System.Windows.Forms.TextBox();
            this.txtMeasurement = new System.Windows.Forms.TextBox();
            this.txtAai = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTotalDue = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtGrandTaxable = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtNonTax = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtTaxAmount = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtTaxPercent = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtTotalTaxable = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtShipperRef = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtMaterial = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtWt = new System.Windows.Forms.TextBox();
            this.txtPkt = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtBeNo = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtHawbNo = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtMawbNo = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtPortName = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtInvoice = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.billDate = new System.Windows.Forms.DateTimePicker();
            this.txtPartyName = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtLisc);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.txtAdc);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.txtTransportation);
            this.groupBox1.Controls.Add(this.txtDcc);
            this.groupBox1.Controls.Add(this.txtCmcCha);
            this.groupBox1.Controls.Add(this.txtFork);
            this.groupBox1.Controls.Add(this.txtMarking);
            this.groupBox1.Controls.Add(this.txtMisc);
            this.groupBox1.Controls.Add(this.txtRepacking);
            this.groupBox1.Controls.Add(this.txtDocumentation);
            this.groupBox1.Controls.Add(this.txtCustomDuty);
            this.groupBox1.Controls.Add(this.txtWtDiff);
            this.groupBox1.Controls.Add(this.txtGsp);
            this.groupBox1.Controls.Add(this.txtCha);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtAgency);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 165);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 412);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Taxable Charges";
            // 
            // txtLisc
            // 
            this.txtLisc.Location = new System.Drawing.Point(220, 352);
            this.txtLisc.Name = "txtLisc";
            this.txtLisc.Size = new System.Drawing.Size(72, 20);
            this.txtLisc.TabIndex = 29;
            this.txtLisc.Text = "0";
            this.txtLisc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLisc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtLisc_KeyUp);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(15, 355);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(172, 13);
            this.label42.TabIndex = 28;
            this.label42.Text = "LICENSE PROC. CHARGES :";
            // 
            // txtAdc
            // 
            this.txtAdc.Location = new System.Drawing.Point(220, 328);
            this.txtAdc.Name = "txtAdc";
            this.txtAdc.Size = new System.Drawing.Size(72, 20);
            this.txtAdc.TabIndex = 27;
            this.txtAdc.Text = "0";
            this.txtAdc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAdc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAdc_KeyUp);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(15, 331);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(187, 13);
            this.label41.TabIndex = 26;
            this.label41.Text = "ADC PROCESSING CHARGES :";
            // 
            // txtTransportation
            // 
            this.txtTransportation.Location = new System.Drawing.Point(220, 302);
            this.txtTransportation.Name = "txtTransportation";
            this.txtTransportation.Size = new System.Drawing.Size(72, 20);
            this.txtTransportation.TabIndex = 25;
            this.txtTransportation.Text = "0";
            this.txtTransportation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTransportation.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTransportation_KeyUp);
            // 
            // txtDcc
            // 
            this.txtDcc.Location = new System.Drawing.Point(220, 277);
            this.txtDcc.Name = "txtDcc";
            this.txtDcc.Size = new System.Drawing.Size(72, 20);
            this.txtDcc.TabIndex = 24;
            this.txtDcc.Text = "0";
            this.txtDcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDcc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDcc_KeyUp);
            // 
            // txtCmcCha
            // 
            this.txtCmcCha.Location = new System.Drawing.Point(220, 253);
            this.txtCmcCha.Name = "txtCmcCha";
            this.txtCmcCha.Size = new System.Drawing.Size(72, 20);
            this.txtCmcCha.TabIndex = 23;
            this.txtCmcCha.Text = "0";
            this.txtCmcCha.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCmcCha.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCmcCha_KeyUp);
            // 
            // txtFork
            // 
            this.txtFork.Location = new System.Drawing.Point(220, 228);
            this.txtFork.Name = "txtFork";
            this.txtFork.Size = new System.Drawing.Size(72, 20);
            this.txtFork.TabIndex = 22;
            this.txtFork.Text = "0";
            this.txtFork.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFork.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtFork_KeyUp);
            // 
            // txtMarking
            // 
            this.txtMarking.Location = new System.Drawing.Point(220, 204);
            this.txtMarking.Name = "txtMarking";
            this.txtMarking.Size = new System.Drawing.Size(72, 20);
            this.txtMarking.TabIndex = 21;
            this.txtMarking.Text = "0";
            this.txtMarking.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMarking.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMarking_KeyUp);
            // 
            // txtMisc
            // 
            this.txtMisc.Location = new System.Drawing.Point(220, 179);
            this.txtMisc.Name = "txtMisc";
            this.txtMisc.Size = new System.Drawing.Size(72, 20);
            this.txtMisc.TabIndex = 20;
            this.txtMisc.Text = "0";
            this.txtMisc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMisc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMisc_KeyUp);
            // 
            // txtRepacking
            // 
            this.txtRepacking.Location = new System.Drawing.Point(220, 154);
            this.txtRepacking.Name = "txtRepacking";
            this.txtRepacking.Size = new System.Drawing.Size(72, 20);
            this.txtRepacking.TabIndex = 19;
            this.txtRepacking.Text = "0";
            this.txtRepacking.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRepacking.TextChanged += new System.EventHandler(this.txtRepacking_TextChanged);
            this.txtRepacking.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtRepacking_KeyUp);
            // 
            // txtDocumentation
            // 
            this.txtDocumentation.Location = new System.Drawing.Point(220, 132);
            this.txtDocumentation.Name = "txtDocumentation";
            this.txtDocumentation.Size = new System.Drawing.Size(72, 20);
            this.txtDocumentation.TabIndex = 18;
            this.txtDocumentation.Text = "0";
            this.txtDocumentation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDocumentation.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDocumentation_KeyUp);
            // 
            // txtCustomDuty
            // 
            this.txtCustomDuty.Location = new System.Drawing.Point(220, 109);
            this.txtCustomDuty.Name = "txtCustomDuty";
            this.txtCustomDuty.Size = new System.Drawing.Size(72, 20);
            this.txtCustomDuty.TabIndex = 17;
            this.txtCustomDuty.Text = "0";
            this.txtCustomDuty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCustomDuty.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCustomDuty_KeyUp);
            // 
            // txtWtDiff
            // 
            this.txtWtDiff.Location = new System.Drawing.Point(220, 87);
            this.txtWtDiff.Name = "txtWtDiff";
            this.txtWtDiff.Size = new System.Drawing.Size(72, 20);
            this.txtWtDiff.TabIndex = 16;
            this.txtWtDiff.Text = "0";
            this.txtWtDiff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtWtDiff.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtWtDiff_KeyUp);
            // 
            // txtGsp
            // 
            this.txtGsp.Location = new System.Drawing.Point(220, 64);
            this.txtGsp.Name = "txtGsp";
            this.txtGsp.Size = new System.Drawing.Size(72, 20);
            this.txtGsp.TabIndex = 15;
            this.txtGsp.Text = "0";
            this.txtGsp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGsp.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtGsp_KeyUp);
            // 
            // txtCha
            // 
            this.txtCha.Location = new System.Drawing.Point(220, 42);
            this.txtCha.Name = "txtCha";
            this.txtCha.Size = new System.Drawing.Size(72, 20);
            this.txtCha.TabIndex = 14;
            this.txtCha.Text = "0";
            this.txtCha.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCha.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCha_KeyUp);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 305);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(190, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "TRANSPORTATION/LOADING :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 284);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(201, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "DCC/MINISTRY/LEAGLISATION :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 256);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "CMC CHA:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 231);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(173, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "FORK/CRANE CH./CTG CH :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(201, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "WITHOUT MARKING/LABELING :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(145, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "MISC CH.(APRAISING) :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "OPEN REPACKING/STRAPPING :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "DOCUMENTION :";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "CUSTOM DUTY :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "WT. DIFF AMT :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "GSP/DCC :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "CHA MOT / W/L NOC :";
            // 
            // txtAgency
            // 
            this.txtAgency.Location = new System.Drawing.Point(220, 19);
            this.txtAgency.Name = "txtAgency";
            this.txtAgency.Size = new System.Drawing.Size(72, 20);
            this.txtAgency.TabIndex = 1;
            this.txtAgency.Text = "0";
            this.txtAgency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAgency.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtAgency.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAgency_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "AGENCY :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtChargesAirlines);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.txtContainer);
            this.groupBox2.Controls.Add(this.txtLoading);
            this.groupBox2.Controls.Add(this.txtDOCharges);
            this.groupBox2.Controls.Add(this.txtDamurrage);
            this.groupBox2.Controls.Add(this.txtAAIWT);
            this.groupBox2.Controls.Add(this.txtTR6);
            this.groupBox2.Controls.Add(this.txtBillLading);
            this.groupBox2.Controls.Add(this.txtAirFreight);
            this.groupBox2.Controls.Add(this.txtMeasurement);
            this.groupBox2.Controls.Add(this.txtAai);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Location = new System.Drawing.Point(337, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(308, 413);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reimbursable Charges";
            // 
            // txtChargesAirlines
            // 
            this.txtChargesAirlines.Location = new System.Drawing.Point(220, 270);
            this.txtChargesAirlines.Name = "txtChargesAirlines";
            this.txtChargesAirlines.Size = new System.Drawing.Size(72, 20);
            this.txtChargesAirlines.TabIndex = 37;
            this.txtChargesAirlines.Text = "0";
            this.txtChargesAirlines.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtChargesAirlines.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtChargesAirlines_KeyUp);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(15, 273);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(189, 13);
            this.label38.TabIndex = 36;
            this.label38.Text = "CHARGES RECD. BY AIRLINE :";
            // 
            // txtContainer
            // 
            this.txtContainer.Location = new System.Drawing.Point(220, 246);
            this.txtContainer.Name = "txtContainer";
            this.txtContainer.Size = new System.Drawing.Size(72, 20);
            this.txtContainer.TabIndex = 35;
            this.txtContainer.Text = "0";
            this.txtContainer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtContainer.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtContainer_KeyUp);
            // 
            // txtLoading
            // 
            this.txtLoading.Location = new System.Drawing.Point(221, 205);
            this.txtLoading.Name = "txtLoading";
            this.txtLoading.Size = new System.Drawing.Size(72, 20);
            this.txtLoading.TabIndex = 34;
            this.txtLoading.Text = "0";
            this.txtLoading.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLoading.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtLoading_KeyUp);
            // 
            // txtDOCharges
            // 
            this.txtDOCharges.Location = new System.Drawing.Point(221, 180);
            this.txtDOCharges.Name = "txtDOCharges";
            this.txtDOCharges.Size = new System.Drawing.Size(72, 20);
            this.txtDOCharges.TabIndex = 33;
            this.txtDOCharges.Text = "0";
            this.txtDOCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDOCharges.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDOCharges_KeyUp);
            // 
            // txtDamurrage
            // 
            this.txtDamurrage.Location = new System.Drawing.Point(221, 157);
            this.txtDamurrage.Name = "txtDamurrage";
            this.txtDamurrage.Size = new System.Drawing.Size(72, 20);
            this.txtDamurrage.TabIndex = 32;
            this.txtDamurrage.Text = "0";
            this.txtDamurrage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDamurrage.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDamurrage_KeyUp);
            // 
            // txtAAIWT
            // 
            this.txtAAIWT.Location = new System.Drawing.Point(221, 134);
            this.txtAAIWT.Name = "txtAAIWT";
            this.txtAAIWT.Size = new System.Drawing.Size(72, 20);
            this.txtAAIWT.TabIndex = 31;
            this.txtAAIWT.Text = "0";
            this.txtAAIWT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAAIWT.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAAIWT_KeyUp);
            // 
            // txtTR6
            // 
            this.txtTR6.Location = new System.Drawing.Point(221, 110);
            this.txtTR6.Name = "txtTR6";
            this.txtTR6.Size = new System.Drawing.Size(72, 20);
            this.txtTR6.TabIndex = 30;
            this.txtTR6.Text = "0";
            this.txtTR6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTR6.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTR6_KeyUp);
            // 
            // txtBillLading
            // 
            this.txtBillLading.Location = new System.Drawing.Point(221, 88);
            this.txtBillLading.Name = "txtBillLading";
            this.txtBillLading.Size = new System.Drawing.Size(72, 20);
            this.txtBillLading.TabIndex = 29;
            this.txtBillLading.Text = "0";
            this.txtBillLading.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBillLading.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBillLading_KeyUp);
            // 
            // txtAirFreight
            // 
            this.txtAirFreight.Location = new System.Drawing.Point(220, 65);
            this.txtAirFreight.Name = "txtAirFreight";
            this.txtAirFreight.Size = new System.Drawing.Size(72, 20);
            this.txtAirFreight.TabIndex = 28;
            this.txtAirFreight.Text = "0";
            this.txtAirFreight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAirFreight.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAirFreight_KeyUp);
            // 
            // txtMeasurement
            // 
            this.txtMeasurement.Location = new System.Drawing.Point(220, 43);
            this.txtMeasurement.Name = "txtMeasurement";
            this.txtMeasurement.Size = new System.Drawing.Size(72, 20);
            this.txtMeasurement.TabIndex = 27;
            this.txtMeasurement.Text = "0";
            this.txtMeasurement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMeasurement.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMeasurement_KeyUp);
            // 
            // txtAai
            // 
            this.txtAai.Location = new System.Drawing.Point(220, 21);
            this.txtAai.Name = "txtAai";
            this.txtAai.Size = new System.Drawing.Size(72, 20);
            this.txtAai.TabIndex = 26;
            this.txtAai.Text = "0";
            this.txtAai.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAai.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAai_KeyUp);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(15, 249);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(203, 13);
            this.label20.TabIndex = 23;
            this.label20.Text = "YARD TO PORT/PORT TO YARD:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(15, 232);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(175, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "CONTAINER OUT  RECT CH-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(15, 208);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "LOADING UNLOADING :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 183);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 13);
            this.label16.TabIndex = 20;
            this.label16.Text = "DO CHARGES :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(15, 162);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(200, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "AAI DAMURRAGE OR PANELTY :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(15, 137);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(135, 13);
            this.label18.TabIndex = 18;
            this.label18.Text = "AAI WT DIFF TC. CH :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(15, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 13);
            this.label19.TabIndex = 17;
            this.label19.Text = "TR 6 CHALLAN :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(15, 90);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "BILL OF LADING :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(15, 68);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(130, 13);
            this.label22.TabIndex = 14;
            this.label22.Text = "AIR FRT / SEA FRT :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(15, 43);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(131, 13);
            this.label23.TabIndex = 13;
            this.label23.Text = "MEASUREMENT CH :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(15, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(153, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "AAI CH/CWC CHARGES :";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox3.Controls.Add(this.txtTotalDue);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.txtGrandTaxable);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.txtNonTax);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.txtTaxAmount);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.txtTaxPercent);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.txtTotalTaxable);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(660, 168);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(111, 386);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Action";
            // 
            // txtTotalDue
            // 
            this.txtTotalDue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtTotalDue.Location = new System.Drawing.Point(10, 292);
            this.txtTotalDue.Name = "txtTotalDue";
            this.txtTotalDue.ReadOnly = true;
            this.txtTotalDue.Size = new System.Drawing.Size(79, 20);
            this.txtTotalDue.TabIndex = 46;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(6, 269);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(63, 13);
            this.label40.TabIndex = 45;
            this.label40.Text = "Total Due";
            // 
            // txtGrandTaxable
            // 
            this.txtGrandTaxable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtGrandTaxable.Location = new System.Drawing.Point(11, 187);
            this.txtGrandTaxable.Name = "txtGrandTaxable";
            this.txtGrandTaxable.ReadOnly = true;
            this.txtGrandTaxable.Size = new System.Drawing.Size(79, 20);
            this.txtGrandTaxable.TabIndex = 44;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(8, 163);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(90, 13);
            this.label39.TabIndex = 43;
            this.label39.Text = "Grand Taxable";
            // 
            // txtNonTax
            // 
            this.txtNonTax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtNonTax.Location = new System.Drawing.Point(11, 238);
            this.txtNonTax.Name = "txtNonTax";
            this.txtNonTax.ReadOnly = true;
            this.txtNonTax.Size = new System.Drawing.Size(79, 20);
            this.txtNonTax.TabIndex = 42;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(8, 109);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(74, 13);
            this.label37.TabIndex = 41;
            this.label37.Text = "Tax Amount";
            // 
            // txtTaxAmount
            // 
            this.txtTaxAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtTaxAmount.Location = new System.Drawing.Point(11, 133);
            this.txtTaxAmount.Name = "txtTaxAmount";
            this.txtTaxAmount.ReadOnly = true;
            this.txtTaxAmount.Size = new System.Drawing.Size(79, 20);
            this.txtTaxAmount.TabIndex = 40;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(8, 61);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(37, 13);
            this.label36.TabIndex = 39;
            this.label36.Text = "Tax%";
            // 
            // txtTaxPercent
            // 
            this.txtTaxPercent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtTaxPercent.Location = new System.Drawing.Point(11, 81);
            this.txtTaxPercent.Name = "txtTaxPercent";
            this.txtTaxPercent.Size = new System.Drawing.Size(79, 20);
            this.txtTaxPercent.TabIndex = 38;
            this.txtTaxPercent.Text = "12.36";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(8, 215);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(92, 13);
            this.label35.TabIndex = 37;
            this.label35.Text = "Total Non Tax.";
            // 
            // txtTotalTaxable
            // 
            this.txtTotalTaxable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtTotalTaxable.Location = new System.Drawing.Point(11, 35);
            this.txtTotalTaxable.Name = "txtTotalTaxable";
            this.txtTotalTaxable.ReadOnly = true;
            this.txtTotalTaxable.Size = new System.Drawing.Size(79, 20);
            this.txtTotalTaxable.TabIndex = 36;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(6, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 13);
            this.label34.TabIndex = 26;
            this.label34.Text = "Total Taxable";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(11, 352);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "&Print";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 323);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "&Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtShipperRef);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.txtMaterial);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.txtWt);
            this.groupBox4.Controls.Add(this.txtPkt);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.txtBeNo);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.txtHawbNo);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.txtMawbNo);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.txtPortName);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.txtInvoice);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.billDate);
            this.groupBox4.Controls.Add(this.txtPartyName);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Location = new System.Drawing.Point(12, 1);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(760, 165);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Client Details";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // txtShipperRef
            // 
            this.txtShipperRef.Location = new System.Drawing.Point(639, 66);
            this.txtShipperRef.Name = "txtShipperRef";
            this.txtShipperRef.Size = new System.Drawing.Size(115, 20);
            this.txtShipperRef.TabIndex = 57;
            this.txtShipperRef.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtShipperRef_KeyUp);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(542, 68);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(93, 13);
            this.label43.TabIndex = 56;
            this.label43.Text = "SHIPPER REF.";
            // 
            // txtMaterial
            // 
            this.txtMaterial.Location = new System.Drawing.Point(387, 127);
            this.txtMaterial.Name = "txtMaterial";
            this.txtMaterial.Size = new System.Drawing.Size(153, 20);
            this.txtMaterial.TabIndex = 55;
            this.txtMaterial.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMaterial_KeyUp);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(291, 130);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 13);
            this.label33.TabIndex = 54;
            this.label33.Text = "MATERIAL :";
            // 
            // txtWt
            // 
            this.txtWt.Location = new System.Drawing.Point(471, 96);
            this.txtWt.Name = "txtWt";
            this.txtWt.Size = new System.Drawing.Size(69, 20);
            this.txtWt.TabIndex = 53;
            this.txtWt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtWt_KeyUp);
            // 
            // txtPkt
            // 
            this.txtPkt.Location = new System.Drawing.Point(386, 96);
            this.txtPkt.Name = "txtPkt";
            this.txtPkt.Size = new System.Drawing.Size(69, 20);
            this.txtPkt.TabIndex = 52;
            this.txtPkt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPkt_KeyUp);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(291, 99);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 13);
            this.label32.TabIndex = 51;
            this.label32.Text = "PKT/WT :";
            // 
            // txtBeNo
            // 
            this.txtBeNo.Location = new System.Drawing.Point(387, 65);
            this.txtBeNo.Name = "txtBeNo";
            this.txtBeNo.Size = new System.Drawing.Size(153, 20);
            this.txtBeNo.TabIndex = 50;
            this.txtBeNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBeNo_KeyUp);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(291, 68);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(96, 13);
            this.label31.TabIndex = 49;
            this.label31.Text = "BE/SB NO.DT :";
            // 
            // txtHawbNo
            // 
            this.txtHawbNo.Location = new System.Drawing.Point(125, 127);
            this.txtHawbNo.Name = "txtHawbNo";
            this.txtHawbNo.Size = new System.Drawing.Size(153, 20);
            this.txtHawbNo.TabIndex = 48;
            this.txtHawbNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtHawbNo_KeyUp);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(21, 130);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(101, 13);
            this.label30.TabIndex = 47;
            this.label30.Text = "HAWB NO./DT :";
            // 
            // txtMawbNo
            // 
            this.txtMawbNo.Location = new System.Drawing.Point(125, 96);
            this.txtMawbNo.Name = "txtMawbNo";
            this.txtMawbNo.Size = new System.Drawing.Size(153, 20);
            this.txtMawbNo.TabIndex = 46;
            this.txtMawbNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMawbNo_KeyUp);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(21, 99);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(102, 13);
            this.label29.TabIndex = 45;
            this.label29.Text = "MAWB NO./DT :";
            // 
            // txtPortName
            // 
            this.txtPortName.Location = new System.Drawing.Point(125, 66);
            this.txtPortName.Name = "txtPortName";
            this.txtPortName.Size = new System.Drawing.Size(153, 20);
            this.txtPortName.TabIndex = 44;
            this.txtPortName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPortName_KeyUp);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(21, 68);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 13);
            this.label28.TabIndex = 43;
            this.label28.Text = "PORT NAME :";
            // 
            // txtInvoice
            // 
            this.txtInvoice.Location = new System.Drawing.Point(639, 32);
            this.txtInvoice.Name = "txtInvoice";
            this.txtInvoice.Size = new System.Drawing.Size(115, 20);
            this.txtInvoice.TabIndex = 36;
            this.txtInvoice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtInvoice_KeyUp);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(542, 35);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 13);
            this.label27.TabIndex = 42;
            this.label27.Text = "INVOICE NO. :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(290, 35);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(78, 13);
            this.label26.TabIndex = 26;
            this.label26.Text = "BILL DATE :";
            // 
            // billDate
            // 
            this.billDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.billDate.Location = new System.Drawing.Point(387, 32);
            this.billDate.Name = "billDate";
            this.billDate.Size = new System.Drawing.Size(152, 20);
            this.billDate.TabIndex = 41;
            this.billDate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.billDate_KeyUp);
            // 
            // txtPartyName
            // 
            this.txtPartyName.FormattingEnabled = true;
            this.txtPartyName.Location = new System.Drawing.Point(125, 32);
            this.txtPartyName.Name = "txtPartyName";
            this.txtPartyName.Size = new System.Drawing.Size(153, 21);
            this.txtPartyName.TabIndex = 27;
            this.txtPartyName.SelectedIndexChanged += new System.EventHandler(this.txtPartyName_SelectedIndexChanged);
            this.txtPartyName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPartyName_KeyUp);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(21, 35);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(98, 13);
            this.label25.TabIndex = 26;
            this.label25.Text = "CLIENT NAME :";
            // 
            // CargoBilling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(789, 582);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CargoBilling";
            this.Text = "CargoBilling";
            this.Load += new System.EventHandler(this.CargoBilling_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAgency;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDocumentation;
        private System.Windows.Forms.TextBox txtCustomDuty;
        private System.Windows.Forms.TextBox txtWtDiff;
        private System.Windows.Forms.TextBox txtGsp;
        private System.Windows.Forms.TextBox txtCha;
        private System.Windows.Forms.TextBox txtTransportation;
        private System.Windows.Forms.TextBox txtDcc;
        private System.Windows.Forms.TextBox txtCmcCha;
        private System.Windows.Forms.TextBox txtFork;
        private System.Windows.Forms.TextBox txtMarking;
        private System.Windows.Forms.TextBox txtMisc;
        private System.Windows.Forms.TextBox txtRepacking;
        private System.Windows.Forms.TextBox txtContainer;
        private System.Windows.Forms.TextBox txtLoading;
        private System.Windows.Forms.TextBox txtDOCharges;
        private System.Windows.Forms.TextBox txtDamurrage;
        private System.Windows.Forms.TextBox txtAAIWT;
        private System.Windows.Forms.TextBox txtTR6;
        private System.Windows.Forms.TextBox txtBillLading;
        private System.Windows.Forms.TextBox txtAirFreight;
        private System.Windows.Forms.TextBox txtMeasurement;
        private System.Windows.Forms.TextBox txtAai;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox txtPartyName;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtMaterial;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtWt;
        private System.Windows.Forms.TextBox txtPkt;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtBeNo;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtHawbNo;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtMawbNo;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtPortName;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtInvoice;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker billDate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtNonTax;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtTaxAmount;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtTaxPercent;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtTotalTaxable;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtChargesAirlines;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtTotalDue;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtGrandTaxable;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtLisc;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtAdc;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtShipperRef;
        private System.Windows.Forms.Label label43;

    }
}