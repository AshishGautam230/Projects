﻿namespace CRM
{
    partial class SearchQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchQuery));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReport = new System.Windows.Forms.Button();
            this.lstQuery = new System.Windows.Forms.ListView();
            this.QueryID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CallDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.FollowUP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Remark = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Query = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UserName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CustomerName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Contact = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EMail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Address = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.OldQueryID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.QueryType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtQueryID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lnkSearch = new System.Windows.Forms.LinkLabel();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnReport);
            this.groupBox1.Controls.Add(this.lstQuery);
            this.groupBox1.Controls.Add(this.txtQueryID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lnkSearch);
            this.groupBox1.Controls.Add(this.txtCustomerID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1240, 482);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Query";
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(734, 22);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(134, 26);
            this.btnReport.TabIndex = 19;
            this.btnReport.Text = "Generate Report";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // lstQuery
            // 
            this.lstQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstQuery.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.QueryID,
            this.CallDate,
            this.FollowUP,
            this.Remark,
            this.Query,
            this.UserName,
            this.CustomerName,
            this.Contact,
            this.EMail,
            this.Address,
            this.OldQueryID,
            this.CID,
            this.QueryType,
            this.Status});
            this.lstQuery.FullRowSelect = true;
            this.lstQuery.GridLines = true;
            this.lstQuery.Location = new System.Drawing.Point(3, 62);
            this.lstQuery.MultiSelect = false;
            this.lstQuery.Name = "lstQuery";
            this.lstQuery.Size = new System.Drawing.Size(1234, 417);
            this.lstQuery.TabIndex = 1;
            this.lstQuery.UseCompatibleStateImageBehavior = false;
            this.lstQuery.View = System.Windows.Forms.View.Details;
            this.lstQuery.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstQuery_MouseDoubleClick);
            // 
            // QueryID
            // 
            this.QueryID.Text = "Query ID";
            this.QueryID.Width = 90;
            // 
            // CallDate
            // 
            this.CallDate.Text = "Date";
            this.CallDate.Width = 90;
            // 
            // FollowUP
            // 
            this.FollowUP.Text = "Follow Date";
            this.FollowUP.Width = 90;
            // 
            // Remark
            // 
            this.Remark.Text = "Remark";
            this.Remark.Width = 250;
            // 
            // Query
            // 
            this.Query.Text = "Query";
            this.Query.Width = 250;
            // 
            // UserName
            // 
            this.UserName.Text = "User";
            this.UserName.Width = 70;
            // 
            // CustomerName
            // 
            this.CustomerName.Text = "Customer Name";
            this.CustomerName.Width = 120;
            // 
            // Contact
            // 
            this.Contact.Text = "Contact";
            this.Contact.Width = 80;
            // 
            // EMail
            // 
            this.EMail.Text = "EMail";
            this.EMail.Width = 0;
            // 
            // Address
            // 
            this.Address.Text = "Address";
            this.Address.Width = 0;
            // 
            // OldQueryID
            // 
            this.OldQueryID.Text = "OldQueryID";
            this.OldQueryID.Width = 0;
            // 
            // CID
            // 
            this.CID.Text = "CustomerID";
            this.CID.Width = 0;
            // 
            // QueryType
            // 
            this.QueryType.Text = "QueryType";
            this.QueryType.Width = 70;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.Width = 80;
            // 
            // txtQueryID
            // 
            this.txtQueryID.Location = new System.Drawing.Point(467, 24);
            this.txtQueryID.Name = "txtQueryID";
            this.txtQueryID.Size = new System.Drawing.Size(190, 22);
            this.txtQueryID.TabIndex = 4;
            this.txtQueryID.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Query ID:";
            // 
            // lnkSearch
            // 
            this.lnkSearch.AutoSize = true;
            this.lnkSearch.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkSearch.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkSearch.Location = new System.Drawing.Point(306, 29);
            this.lnkSearch.Name = "lnkSearch";
            this.lnkSearch.Size = new System.Drawing.Size(41, 13);
            this.lnkSearch.TabIndex = 2;
            this.lnkSearch.TabStop = true;
            this.lnkSearch.Text = "Search";
            this.lnkSearch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSearch_LinkClicked);
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(110, 24);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.Size = new System.Drawing.Size(190, 22);
            this.txtCustomerID.TabIndex = 1;
            this.txtCustomerID.TextChanged += new System.EventHandler(this.txtCustomerID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer ID:";
            // 
            // SearchQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1266, 500);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchQuery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Query";
            this.Load += new System.EventHandler(this.SearchQuery_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.LinkLabel lnkSearch;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQueryID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lstQuery;
        private System.Windows.Forms.ColumnHeader QueryID;
        private System.Windows.Forms.ColumnHeader CallDate;
        private System.Windows.Forms.ColumnHeader FollowUP;
        private System.Windows.Forms.ColumnHeader Remark;
        private System.Windows.Forms.ColumnHeader Query;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.ColumnHeader UserName;
        private System.Windows.Forms.ColumnHeader CustomerName;
        private System.Windows.Forms.ColumnHeader Contact;
        private System.Windows.Forms.ColumnHeader EMail;
        private System.Windows.Forms.ColumnHeader Address;
        private System.Windows.Forms.ColumnHeader OldQueryID;
        private System.Windows.Forms.ColumnHeader CID;
        private System.Windows.Forms.ColumnHeader QueryType;
        private System.Windows.Forms.ColumnHeader Status;
    }
}