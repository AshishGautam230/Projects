﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

using System.Windows.Forms;
using System.Net;
using System.IO;

namespace CRM
{
    public partial class SendSMS : Form
    {
        public SendSMS()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string messagetxt = "";

            if (comboBox1.Text == "Promotional")
            {
                messagetxt = "Get best rate for your international courier through DHL/FedEx/TNT/Aramex. Global India Express, 24X7 Helpline: 07532000360.";
                
            }
            else if (comboBox1.Text == "Rate")
            {
                messagetxt = "Rate for your shipment from Delhi to ------ upto  --- KG with DHL---- is RS.----. Please call 07532000360 or 01141785200 for free pickup and packaging. Thank you, Global India Express.";
            }
            else if (comboBox1.Text == "Custom")
            {
                messagetxt = "";

            }
            txtText.Text = messagetxt;

        }
        public void sendsms()
        {
            string phone = txtPhone.Text;
            string msgtext = txtText.Text;
            string smsapi = "http://trx.orangesms.net/api/sendmsg.php?user=averma81&pass=123&sender=GLOBAL&phone=" + phone + "&text="+msgtext +"&priority=ndnd&stype=normal";
            WebRequest request = HttpWebRequest.Create(smsapi);
            WebResponse response = request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string urlText = reader.ReadToEnd(); // it takes th
            MessageBox.Show("SMS Sent");
            txtPhone.Text = txtText.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sendsms();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtPhone.Text = txtText.Text = string.Empty;
        }

        private void txtText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
