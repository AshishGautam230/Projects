﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CRM
{
    public partial class MyProfile : Form
    {
        public MyProfile()
        {
            InitializeComponent();
        }

        void GetProfile(int UserID, DateTime Date)
        {
            
            SqlCommand com = new SqlCommand("GetProfile", Methods.GetConnection());
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@UserID", UserID);
            com.Parameters.AddWithValue("@Date", Date.ToShortDateString());
            com.Parameters.AddWithValue("@Total", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@Resolved", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@Cancelled", 0).Direction = ParameterDirection.Output;
            com.ExecuteNonQuery();

            lblTotal.Text = com.Parameters["@Total"].Value.ToString();
            lblResolved.Text = com.Parameters["@Resolved"].Value.ToString();
            lblCancelled.Text = com.Parameters["@Cancelled"].Value.ToString();
        }

        private void MyProfile_Load(object sender, EventArgs e)
        {
            if (Methods.IsAdmin)
            {

                SqlCommand com = new SqlCommand("SELECT UserID, UserName FROM Users", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    cmbUser.Items.Add(reader["UserID"].ToString() + " : " + reader["UserName"].ToString());
                }
                reader.Close();
                if (cmbUser.Items.Count > 0)
                {
                    cmbUser.SelectedIndex =0;
                }
            }
            else
            {
                cmbUser.Visible = lblUser.Visible = false;
                GetProfile(Methods.UserID, dateFollowUp.Value);
            }
            


        }

        private void cmbUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetProfile(Convert.ToInt32(cmbUser.Text.Substring(0, cmbUser.Text.IndexOf(' '))), dateFollowUp.Value);
        }

        private void dateFollowUp_ValueChanged(object sender, EventArgs e)
        {
            if (Methods.IsAdmin)
            {
                GetProfile(Convert.ToInt32(cmbUser.Text.Substring(0, cmbUser.Text.IndexOf(' '))), dateFollowUp.Value);
            }
            else
            {
                GetProfile(Methods.UserID, dateFollowUp.Value);
            }
        }
    }
}
