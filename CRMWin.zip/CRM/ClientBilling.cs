﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Diagnostics;



namespace CRM
{
    public partial class ClientBilling : Form
    {
        public ClientBilling()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ClientBilling_Load(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("select customername from customers order by customername asc", Methods.GetConnection());
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                txtPartyName.Items.Add(reader["customername"].ToString().Trim());
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked)
            {
                label4.Visible = true;
                txttax.Visible = true;
                txttax.Text = "12.36";
            }
            else if (!checkBox1.Checked)
            {
                label4.Visible = false;
                txttax.Visible = false;
                txttax.Text = "0";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*SqlCommand cmdbill = new SqlCommand("select * from booking where partyname=@pname and bookingdate between @datefrom and @dateto", Methods.GetConnection());
            cmdbill.Parameters.AddWithValue("@pname", txtPartyName.Text.Trim());
            cmdbill.Parameters.AddWithValue("@datefrom", dateFrom.Value.ToShortDateString());
            cmdbill.Parameters.AddWithValue("@dateto", dateTo.Value.ToShortDateString());*/
            string invoicedate;
            float payable;
            SqlCommand cmdinvdate = new SqlCommand("select convert(varchar,@invoicedate,104)", Methods.GetConnection());
            cmdinvdate.Parameters.AddWithValue("@invoicedate", invdate.Value.ToShortDateString());
            SqlDataReader sdrinvdate = cmdinvdate.ExecuteReader();
            sdrinvdate.Read();
            invoicedate = sdrinvdate[0].ToString();
            string invno = txtinvno.Text.Trim();
            string filename = invno + ".html";

            string commandText = "SELECT awbno,BookingDate=convert(varchar,bookingdate,104),forwardingno,source,destination,weight,package,amount FROM Booking WHERE BookingDate BETWEEN '" + dateFrom.Text + "' AND '" + dateTo.Text + "' "+" and partyname=@pname";
            SqlCommand cmdtotalamt = new SqlCommand("select sum(amount) from booking WHERE BookingDate BETWEEN '" + dateFrom.Text + "' AND '" + dateTo.Text + "' " + " and partyname=@pname", Methods.GetConnection());
            cmdtotalamt.Parameters.AddWithValue("@pname", txtPartyName.Text.Trim());
            SqlDataReader sdramt = cmdtotalamt.ExecuteReader();
            sdramt.Read();
            float amount = Convert.ToSingle(sdramt[0]);

            float taxpercent=Convert.ToSingle(txttax.Text);

            float n1=amount*taxpercent/100;
            payable=amount+n1;
            
            SqlCommand cmdcustomerdetails = new SqlCommand("select customername,address,contact,email from customers where customername=@cname", Methods.GetConnection());
            cmdcustomerdetails.Parameters.AddWithValue("@cname", txtPartyName.Text);
            SqlDataReader sdrcmdetails = cmdcustomerdetails.ExecuteReader();
            sdrcmdetails.Read();
            string customername = sdrcmdetails["customername"].ToString();
            string customeraddress = sdrcmdetails["address"].ToString();
            string customerphone = sdrcmdetails["contact"].ToString();
            string customeremail = sdrcmdetails["email"].ToString();

            
            SqlCommand com = new SqlCommand(commandText, Methods.GetConnection());
            com.Parameters.AddWithValue("@pname", txtPartyName.Text.Trim());

            SqlDataReader reader = com.ExecuteReader();
            StreamWriter writer = new StreamWriter(new FileStream(filename, FileMode.Create, FileAccess.Write));

            SqlCommand cmdinsertinv = new SqlCommand("insert invoice values(@invoice_no,@customername,@from_date,@to_Date,@total_amount,@tax,@final_amount)", Methods.GetConnection());
            cmdinsertinv.Parameters.AddWithValue("@invoice_no", txtinvno.Text);
            cmdinsertinv.Parameters.AddWithValue("@customername", txtPartyName.Text);
            cmdinsertinv.Parameters.AddWithValue("@from_date", dateFrom.Value.ToShortDateString());
            cmdinsertinv.Parameters.AddWithValue("@to_date", dateTo.Value.ToShortDateString());
            cmdinsertinv.Parameters.AddWithValue("@total_amount", amount);
            cmdinsertinv.Parameters.AddWithValue("@tax", txttax.Text);
            cmdinsertinv.Parameters.AddWithValue("@final_amount",payable);
            cmdinsertinv.ExecuteNonQuery();





            string HtmlReport = "<html><head> <title>Billing Report</title><script>function printreport(){ document.getElementById(\"btnPrint\").style.display = \"none\"; window.print();}</script></head><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px; height:100%;\">" +
                "<table width=\"100%\"><tr><td colspan=\"2\" align=\"left\"><img src=\"headerglobal.png\" height=80 width=860></img></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td><div style=\"height:100px;width:400px;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold\">Billed to:<br/><table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td>" + customername + "</td></tr><tr><td>" + customeraddress + "</td></tr><tr><td>" + customerphone + "</td></tr><tr><td>" + customeremail + "</td></tr></table></div></td><td><div style=\"height:100px;width:400px;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold; float:right;\">Invoice Details:<table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td>Invoice Date:</td><td>" + invoicedate + "</td></tr><tr><td>Invoice No. :<td>" + txtinvno.Text + "</td></tr><tr><td>From Date:</td><td>" + dateFrom.Value.ToShortDateString() + "</td></tr><tr><td>Date To: </td><td>" + dateTo.Value.ToShortDateString() +"</td></tr></table></div></td></tr>" + "<tr><td colspan=\"2\">" +
                               "<br/><div  style=\"align:left; border-radius: 5px; border: 1px solid gray;\">" +
                               "<table style=\"width:100%; font-size: 11; font-weight: bold; \">" +
                               "<tr style=\"background-color: #BDDEFF \"><td>AWB No.</td><td>Date</td><td>Forwarding No.</td><td>Origin</td><td>Destination</td><td>Weight</td><td>Package</td><td>Amount</td></tr>";
            while (reader.Read())
            {
                HtmlReport += "<tr><td>" + reader["AwbNo"].ToString() + "</td><td>" + reader["BookingDate"].ToString() + "</td><td>" + reader["ForwardingNo"].ToString() + "</td><td>" + reader["source"].ToString() + "</td><td>" + reader["Destination"].ToString() + "</td><td>"+reader["Weight"].ToString()+"</td><td>"+reader["package"].ToString()+"</td><td>" + reader["Amount"].ToString() + "</td><td>"+ "</td></tr>";
            }
            reader.Close();

            HtmlReport += "</table>"
             +
                 "</div><br/><div style=\"float:right; width:400px height:100%;border-radius:5px;border: 1px solid gray;\"><table style=\"font-size: 11px; font-weight: bold; font-family: Helvetica;\"><tr><td>Total Amount:</td><td>" + amount.ToString() + "</td></tr><tr><td>Tax %</td><td>"+txttax.Text+"</td></tr><tr><td>Total Payable: </td><td>"+payable+"</td></tr></table></div><br/><br/><br/><center><input type=\"button\" id=\"btnPrint\" value=\"Print\" onclick=\"printreport()\" /></center><br/><div style=\"background-color:#6AAEFA; height: 10px;\" /><br/></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">" + Methods.CompanyName + "<br/>" + Methods.CompanyContact + "<br/>" + Methods.CompanyEmail + "</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
                 "Report By: <a href=\"http://www.globalindiaexpress.com\">Global India Express</a></p></td></tr></table></div></center></body></html>";
            writer.Write(HtmlReport);
            writer.Close();
            Process.Start(filename);



        }

        private void dateTo_ValueChanged(object sender, EventArgs e)
        {

        }

        private void invdate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
