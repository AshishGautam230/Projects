﻿namespace CRM
{
    partial class ListQueries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListQueries));
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lstQueries = new System.Windows.Forms.ListView();
            this.QueryID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.QueryDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CustomerID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CustomerName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Contact = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EMail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Query = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.QueryType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(81, 17);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // lstQueries
            // 
            this.lstQueries.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstQueries.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.QueryID,
            this.QueryDate,
            this.CustomerID,
            this.CustomerName,
            this.Contact,
            this.EMail,
            this.Query,
            this.ID,
            this.QueryType,
            this.Status});
            this.lstQueries.FullRowSelect = true;
            this.lstQueries.GridLines = true;
            this.lstQueries.Location = new System.Drawing.Point(13, 46);
            this.lstQueries.MultiSelect = false;
            this.lstQueries.Name = "lstQueries";
            this.lstQueries.Size = new System.Drawing.Size(1039, 444);
            this.lstQueries.TabIndex = 2;
            this.lstQueries.UseCompatibleStateImageBehavior = false;
            this.lstQueries.View = System.Windows.Forms.View.Details;
            this.lstQueries.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstQueries_MouseDoubleClick);
            // 
            // QueryID
            // 
            this.QueryID.Text = "Query ID";
            this.QueryID.Width = 100;
            // 
            // QueryDate
            // 
            this.QueryDate.Text = "Query Date";
            this.QueryDate.Width = 100;
            // 
            // CustomerID
            // 
            this.CustomerID.Text = "Customer ID";
            this.CustomerID.Width = 0;
            // 
            // CustomerName
            // 
            this.CustomerName.Text = "Name";
            this.CustomerName.Width = 200;
            // 
            // Contact
            // 
            this.Contact.Text = "Contact";
            this.Contact.Width = 90;
            // 
            // EMail
            // 
            this.EMail.Text = "Email";
            this.EMail.Width = 150;
            // 
            // Query
            // 
            this.Query.Text = "Query";
            this.Query.Width = 180;
            // 
            // ID
            // 
            this.ID.Text = "OldQueryID";
            this.ID.Width = 0;
            // 
            // QueryType
            // 
            this.QueryType.Text = "QueryType";
            this.QueryType.Width = 80;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.Width = 110;
            // 
            // ListQueries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1064, 502);
            this.Controls.Add(this.lstQueries);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ListQueries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List Queries";
            this.Load += new System.EventHandler(this.ListQueries_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ListView lstQueries;
        private System.Windows.Forms.ColumnHeader QueryID;
        private System.Windows.Forms.ColumnHeader QueryDate;
        private System.Windows.Forms.ColumnHeader CustomerID;
        private System.Windows.Forms.ColumnHeader CustomerName;
        private System.Windows.Forms.ColumnHeader Contact;
        public System.Windows.Forms.ColumnHeader EMail;
        private System.Windows.Forms.ColumnHeader Query;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader QueryType;
        private System.Windows.Forms.ColumnHeader Status;
    }
}