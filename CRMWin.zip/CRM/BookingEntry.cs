﻿namespace CRM
{
    using System;
    using System.Data.SqlClient;
    using System.Windows.Forms;
    using System.Net;
    using System.Net.Mail;
    using System.IO;
    public partial class BookingEntry : Form
    {
        string record;
        public BookingEntry()
        {
            InitializeComponent();
            ddlNetwork.SelectedIndex = 0;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string vendorno = "";
            float weight = 0;
            
            
            vendorno = txtvendorawb.Text;
            weight = Convert.ToSingle(txtweight.Text);
            SqlCommand com = new SqlCommand("NewBooking", Methods.GetConnection());
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@AwbNo", txtAwnNo.Text);
            com.Parameters.AddWithValue("@PartyName", txtPartyName.Text);
            com.Parameters.AddWithValue("@Contact", txtPartyContact.Text);
            com.Parameters.AddWithValue("@EMail", txtPartyEmail.Text);
            com.Parameters.AddWithValue("@Vendor", ddlVendor.Text);
            com.Parameters.AddWithValue("@Agency", ddlNetwork.Text);
            com.Parameters.AddWithValue("@ForwardingNo", txtForwardingNo.Text);
            com.Parameters.AddWithValue("@BookingDate", dateBooking.Value.ToShortDateString());
            com.Parameters.AddWithValue("@Status", ddlStatus.Text);
            com.Parameters.AddWithValue("@Remark", txtRemark.Text);
            com.Parameters.AddWithValue("@UserID", Methods.UserID);
            com.Parameters.AddWithValue("@Source", txtSource.Text);
            com.Parameters.AddWithValue("@Destination", txtDestination.Text);
            com.Parameters.AddWithValue("@Boy", ddlPickupBoy.Text);
            com.Parameters.AddWithValue("@Amount", txtAmount.Text);
            com.Parameters.AddWithValue("@consignee", txtconsignee.Text);
            com.Parameters.AddWithValue("@qtype", dlqtype.Text);
            com.Parameters.AddWithValue("@weight",weight);
            com.Parameters.AddWithValue("@vendor_no",vendorno);
            com.Parameters.AddWithValue("@package", Convert.ToInt32(txtpkg.Text));
            if (com.ExecuteNonQuery() == 2)


                if (record != "Yes")
                {

                    SqlCommand cmdcheckcm = new SqlCommand("select  * from customers where customername=@cname", Methods.GetConnection());
                    cmdcheckcm.Parameters.AddWithValue("@cname", txtPartyName.Text.Trim());
                    SqlDataReader sdrcheckcm = cmdcheckcm.ExecuteReader();
                    sdrcheckcm.Read();
                    if (!sdrcheckcm.HasRows)
                    {
                        SqlCommand cmdinsert = new SqlCommand("insert customers values(@cname,@contact,@email,@address,@userid,@regdate)", Methods.GetConnection());
                        cmdinsert.Parameters.AddWithValue("@cname", txtPartyName.Text);
                        cmdinsert.Parameters.AddWithValue("@contact", txtPartyContact.Text);
                        cmdinsert.Parameters.AddWithValue("@email", txtPartyEmail.Text);
                        cmdinsert.Parameters.AddWithValue("@address", txtSource.Text);
                        cmdinsert.Parameters.AddWithValue("@userid", "1");
                        cmdinsert.Parameters.AddWithValue("@regdate", dateBooking.Text);
                        cmdinsert.ExecuteNonQuery();
                    }



/*                    SqlCommand cmdinsert = new SqlCommand("insert customers values(@cname,@contact,@email,@address,@userid,@regdate)", Methods.GetConnection());
                    cmdinsert.Parameters.AddWithValue("@cname", txtPartyName.Text);
                    cmdinsert.Parameters.AddWithValue("@contact", txtPartyContact.Text);
                    cmdinsert.Parameters.AddWithValue("@email", txtPartyEmail.Text);
                    cmdinsert.Parameters.AddWithValue("@address", txtSource.Text);
                    cmdinsert.Parameters.AddWithValue("@userid", "1");
                    cmdinsert.Parameters.AddWithValue("@regdate", dateBooking.Text);
                    cmdinsert.ExecuteNonQuery();*/

                }
                if(chkalert.Checked==true)
                {
                    bookingemailnsms(txtAwnNo.Text, txtPartyName.Text, txtPartyEmail.Text, txtPartyContact.Text, txtSource.Text, txtDestination.Text, txtForwardingNo.Text, ddlNetwork.Text);
                }
                if (MessageBox.Show("Booking details saved!\n Click \"Yes\" to clear text.", "CRM-AppEX", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    txtAwnNo.Text = txtAmount.Text = txtDestination.Text = txtForwardingNo.Text = txtPartyContact.Text = txtPartyEmail.Text = txtPartyName.Text = txtRemark.Text = txtSource.Text = txtconsignee.Text=txtweight.Text=txtvendorawb.Text = string.Empty;
                    txtAwnNo.Focus();

                }
              //  MessageBox.Show(record);

               
       }

        
            

        


        private void BookingEntry_Load(object sender, EventArgs e)
        {
            {
                SqlCommand com = new SqlCommand("SELECT Status FROM BookingStatus", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ddlStatus.Items.Add(reader["Status"].ToString());
                }
                reader.Close();
                if (ddlStatus.Items.Count > 0)
                {
                    ddlStatus.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("select customername from customers order by customername asc", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    txtPartyName.Items.Add(reader["customername"].ToString().Trim());
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Boy FROM PickUpBoys", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ddlPickupBoy.Items.Add(reader["Boy"].ToString());
                }
                reader.Close();
                if (ddlPickupBoy.Items.Count > 0)
                {
                    ddlPickupBoy.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Vendor FROM Vendors", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ddlVendor.Items.Add(reader["Vendor"].ToString());
                }
                reader.Close();
                if (ddlVendor.Items.Count > 0)
                {
                    ddlVendor.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Network FROM Networks", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ddlNetwork.Items.Add(reader["Network"].ToString());
                }
                reader.Close();
                if (ddlNetwork.Items.Count > 0)
                {
                    ddlNetwork.SelectedIndex = 0;
                }
            }
        }

        private void lnkPickUpBoy_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string boyName = Microsoft.VisualBasic.Interaction.InputBox("Enter pickup boy name:", "CRM AppEx", "");
            if (!string.IsNullOrEmpty(boyName))
            {
                SqlCommand com = new SqlCommand("INSERT INTO PickUpBoys (Boy) VALUES (@Boy)", Methods.GetConnection());
                com.Parameters.AddWithValue("@Boy", boyName);
                com.BeginExecuteNonQuery();
                ddlPickupBoy.Items.Add(boyName);
            }
        }

        private void lnkStatus_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string status = Microsoft.VisualBasic.Interaction.InputBox("Enter new status:", "CRM AppEx", "");
            if (!string.IsNullOrEmpty(status))
            {
                SqlCommand com = new SqlCommand("INSERT INTO BookingStatus (Status) VALUES (@Status)", Methods.GetConnection());
                com.Parameters.AddWithValue("@Status", status);
                com.BeginExecuteNonQuery();

                ddlStatus.Items.Add(status);
            }
        }

        private void lnkNetwork_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string network = Microsoft.VisualBasic.Interaction.InputBox("Enter new network:", "CRM AppEx", "");
            if (!string.IsNullOrEmpty(network))
            {
                SqlCommand com = new SqlCommand("INSERT INTO Networks (Network) VALUES (@Network)", Methods.GetConnection());
                com.Parameters.AddWithValue("@Network", network);
                com.BeginExecuteNonQuery();
                ddlNetwork.Items.Add(network);
            }
        }

        private void lnkVendor_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string vendor = Microsoft.VisualBasic.Interaction.InputBox("Enter new vendor:", "CRM AppEx", "");
            if (!string.IsNullOrEmpty(vendor))
            {
                SqlCommand com = new SqlCommand("INSERT INTO Vendors (Vendor) VALUES (@Vendor)", Methods.GetConnection());
                com.Parameters.AddWithValue("@Vendor", vendor);
                com.BeginExecuteNonQuery();

                ddlVendor.Items.Add(vendor);
            }
        }

        private void txtAwnNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                double weightdb;
                string awbno = txtAwnNo.Text;
                SqlCommand cmdfill = new SqlCommand("select * from booking where awbno=@awbno", Methods.GetConnection());
                cmdfill.Parameters.AddWithValue("@awbno", awbno);
                SqlDataReader sdr = cmdfill.ExecuteReader();
                while (sdr.Read())
                {
                    if (sdr.HasRows)
                    {
                        txtPartyName.Text = sdr["PartyName"].ToString();
                        txtPartyContact.Text = sdr["Contact"].ToString();
                        txtPartyEmail.Text = sdr["Email"].ToString();
                        txtSource.Text = sdr["Source"].ToString();
                        txtDestination.Text = sdr["Destination"].ToString();
                        txtconsignee.Text = sdr["Consignee"].ToString();
                        txtAmount.Text = sdr["Amount"].ToString();
                        dateBooking.Text = sdr["BookingDate"].ToString();
                        txtForwardingNo.Text = sdr["ForwardingNo"].ToString();
                        ddlVendor.SelectedItem = sdr["Vendor"].ToString();
                        ddlNetwork.SelectedItem = sdr["Agency"].ToString();
                        ddlPickupBoy.SelectedItem = sdr["PickUpBoy"].ToString();
                        ddlStatus.SelectedItem = sdr["Status"].ToString();
                        dlqtype.SelectedItem = sdr["QType"].ToString();
                        txtvendorawb.Text = sdr["vendor_no"].ToString();
                       // txtweight.Text = sdr["weight"].ToString();
                        weightdb = Convert.ToDouble(sdr["weight"].ToString());
                        double roundedweight = Math.Round(weightdb, 3);
                        txtweight.Text = roundedweight.ToString();
                        //   txtRemark.Text = sdr["Remarks"].ToString();
                        btnInsert.Enabled = false;
                        btnUpdate.Enabled = true;

                    }
                }
                txtPartyName.Focus();
            }
        }


        private void txtPartyEmail_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtPartyContact.Focus();
            }
        }

        private void txtPartyContact_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtSource.Focus();
            }
        }

        private void txtSource_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtDestination.Focus();
            }
        }

        private void txtDestination_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                //txtAmount.Focus();
                txtconsignee.Focus();

            }
        }

        private void txtAmount_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                //dateBooking.Focus();
                txtweight.Focus();
            }
        }

        private void dateBooking_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtForwardingNo.Focus();
            }
        }

        private void txtForwardingNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                ddlVendor.Focus();
            }
        }

        private void ddlVendor_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                //ddlNetwork.Focus();
                txtvendorawb.Focus();
            }
        }

        private void ddlNetwork_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                ddlPickupBoy.Focus();
            }
        }

        private void ddlPickupBoy_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                ddlStatus.Focus();
            }
        }

        private void ddlStatus_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                //txtRemark.Focus();
                dlqtype.Focus();

            }
        }

        private void txtDestination_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtconsignee_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
               // ddlStatus.Focus();
                txtAmount.Focus();
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dlqtype_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                // ddlStatus.Focus();
                txtRemark.Focus();
            }
        }

        public void bookingemailnsms(string awbno,string partyname,string partyemail,string partyphone,string source,string destination,string fwdno,string network)
        {
            string url = Methods.trackurl(network,fwdno);

            string message = "<html><body><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 700px; margin-left:10px\">" + "<p style=\"margin-left:10px;\"><img src=\"http://www.globalindiaexpress.com/images/gie-logo.jpg\" height=60 width=200></img><br><br>Dear Customer,<br>Greetings from Global India Express.<br>Please find the Booking Details of your shipment.<br><strong>Global India Express AWB No.: - " + awbno + "</strong> Destination: <strong>" + destination + "</strong><br><br>Forwarding Network:<strong> " + network + "</strong> Forwarding Number: <strong>" + fwdno + "</strong><br>To track the status of your shipment please <a href=" + url + ">click here</a>.<br><br>If you have any further questions, please feel free to call our Customer Support Team on 011-41785200  or write us to info@globalindiaexpress.com.<br><br>We thank you for choosing <strong>Global India Express</strong> for your shipping requirements.<br><br>Customer Support Team<br>Global India Express<br>L341, Street No. 1,<br>Mahipalpur Extension,<br>New Delhi, 110037.<br><a href=www.globalindiaexpress.com>www.globalindiaexpress.com</a> </p></div></body></html>";
            //SmtpClient smtpClient = new SmtpClient();
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com",587);
            //smtpClient.Host = "smtp.gmail.com";
            smtpClient.EnableSsl = true;
          //  smtpClient.UseDefaultCredentials = true;
            smtpClient.Credentials = new System.Net.NetworkCredential("support@globalindiaexpress.com", "India#123#");
          
            MailMessage mlmsg = new MailMessage();
            mlmsg.From = new MailAddress("support@globalindiaexpress.com","Global India Express");
            
            mlmsg.To.Add( new MailAddress(partyemail));
            mlmsg.Subject = "Global India Express: Shipment Update | " + awbno;
            mlmsg.IsBodyHtml = true;
            mlmsg.Body = message;
            if (partyemail.Length>=4)
            {
                smtpClient.Send(mlmsg);
            }

         //   string smsapi = "http://sms.smsbazar.co.in/rao/trans_sms.php?loginid=amit&password=123456789&sender_id=GLOBAL&to=" + partyphone + "&message=Your shipment with GIE AWB No." + awbno + "to "+destination+" has been forwarded by "+network+" with AWB No. "+fwdno+". Queries, dial 011-41785200.";
//            string smsapi=	http://trx.orangesms.in/api/sendmsg.php?user=averma81&pass=123&sender=GLOBAL&phone=&to=" + partyphone + "&message=Your shipment with GIE AWB No." + awbno + "to "+destination+" has been forwarded by "+network+" with AWB No. "+fwdno+". Queries, dial 011-41785200.";

            string smsapi = "http://trx.orangesms.net/api/sendmsg.php?user=averma81&pass=123&sender=GLOBAL&phone=" + partyphone + "&text=Your shipment with GLOBAL AWB No." + awbno + " to " + destination + " has been forwarded by " + network + " with AWB No. " + fwdno + ". Any questions, call 011-41785200." + "&priority=ndnd&stype=normal";

            WebRequest request = HttpWebRequest.Create(smsapi);
            WebResponse response = request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need 
            // Response.Write(urlText.ToString());





        }
        public void updatebooking()
        {
            float weight;
            if (txtweight.Text.Length <= 0 || txtweight.Text == null)
            {
                weight = 0;
            }
            else
            {
                weight = Convert.ToSingle(txtweight.Text);
            }
           SqlCommand cmdupdate = new SqlCommand("update booking set PartyName=@pname,Contact=@contact,Email=@email,weight=@weight,Vendor=@vendor,vendor_no=@vendorawb,Agency=@agency,ForwardingNo=@fwdno,Source=@source,Destination=@dest,Consignee=@consignee,PickUpBoy=@pickupboy,Amount=@amount,BookingDate=@bdate,QType=@qtype,Status=@status,Package=@package where AwbNo=@awbno",Methods.GetConnection());
           cmdupdate.Parameters.AddWithValue("@awbno", txtAwnNo.Text);
           cmdupdate.Parameters.AddWithValue("@pname", txtPartyName.Text);
           cmdupdate.Parameters.AddWithValue("@contact", txtPartyContact.Text);
           cmdupdate.Parameters.AddWithValue("@email", txtPartyEmail.Text);
           cmdupdate.Parameters.AddWithValue("@vendor", ddlVendor.Text);
           cmdupdate.Parameters.AddWithValue("@agency", ddlNetwork.Text);
           cmdupdate.Parameters.AddWithValue("@fwdno", txtForwardingNo.Text);
           cmdupdate.Parameters.AddWithValue("@source", txtSource.Text);
           cmdupdate.Parameters.AddWithValue("@dest", txtDestination.Text);
           cmdupdate.Parameters.AddWithValue("@consignee", txtconsignee.Text);
           cmdupdate.Parameters.AddWithValue("@pickupboy", ddlPickupBoy.Text);
           cmdupdate.Parameters.AddWithValue("@amount", txtAmount.Text);
           cmdupdate.Parameters.AddWithValue("@bdate", dateBooking.Value.ToShortDateString());
           cmdupdate.Parameters.AddWithValue("@qtype", dlqtype.Text);
           cmdupdate.Parameters.AddWithValue("@status", ddlStatus.Text);
           cmdupdate.Parameters.AddWithValue("@weight", weight);
           cmdupdate.Parameters.AddWithValue("@vendorawb", txtvendorawb.Text);
           cmdupdate.Parameters.AddWithValue("@package", txtpkg.Text);

           cmdupdate.ExecuteNonQuery();
           if (chkalert.Checked == true)
           {
               bookingemailnsms(txtAwnNo.Text, txtPartyName.Text, txtPartyEmail.Text, txtPartyContact.Text, txtSource.Text, txtDestination.Text, txtForwardingNo.Text, ddlNetwork.Text);
           }
           if (MessageBox.Show("Details updated. \n Update another?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
           {
               txtAwnNo.Text = txtAmount.Text = txtDestination.Text = txtForwardingNo.Text = txtPartyContact.Text = txtPartyEmail.Text = txtPartyName.Text = txtRemark.Text = txtSource.Text = txtconsignee.Text=txtweight.Text=txtvendorawb.Text = string.Empty;
               txtAwnNo.Focus();
           }
           else
           {
               btnInsert.Enabled = true;
               btnUpdate.Enabled = false;
               txtAwnNo.Text = txtAmount.Text = txtDestination.Text = txtForwardingNo.Text = txtPartyContact.Text = txtPartyEmail.Text = txtPartyName.Text = txtRemark.Text = txtSource.Text = txtconsignee.Text=txtweight.Text=txtvendorawb.Text = string.Empty;
               txtAwnNo.Focus();
           }


                


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            updatebooking();
        }

        private void txtPartyName_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SqlCommand cmd = new SqlCommand("select Contact,Email,Address from customers where customername=@cname", Methods.GetConnection());
                cmd.Parameters.AddWithValue("@cname", txtPartyName.Text);
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                if (sdr.HasRows == true)
                {
                       txtPartyContact.Text = sdr["contact"].ToString();
                       txtPartyEmail.Text = sdr["Email"].ToString();
                       txtSource.Text = sdr["Address"].ToString();
                       record = "Yes";
                       txtPartyEmail.Focus();
                }
                else
                {
                    txtPartyEmail.Focus();
                }

 
            }
        }

        private void txtPartyName_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select Contact,Email,Address from customers where customername=@cname", Methods.GetConnection());
            cmd.Parameters.AddWithValue("@cname", txtPartyName.Text);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows == true)
            {
                txtPartyContact.Text = sdr["contact"].ToString();
                txtPartyEmail.Text = sdr["Email"].ToString();
                txtSource.Text = sdr["Address"].ToString();
               // record = "Yes";
                txtPartyEmail.Focus();
            }
            else
            {
                txtPartyEmail.Focus();
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtweight_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
            //    dateBooking.Focus();
                txtpkg.Focus();
            }
        }

        private void txtvendorawb_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ddlNetwork.Focus();
            }
        }
        public void insertcustomers()
        {
            SqlCommand cmdinsert = new SqlCommand("insert customers values(@cname,@contact,@email,@address,@userid,@regdate)", Methods.GetConnection());
            cmdinsert.Parameters.AddWithValue("@cname", txtPartyName.Text);
            cmdinsert.Parameters.AddWithValue("@contact", txtPartyContact.Text);
            cmdinsert.Parameters.AddWithValue("@email", txtPartyEmail.Text);
            cmdinsert.Parameters.AddWithValue("@address", txtSource.Text);
            cmdinsert.Parameters.AddWithValue("@userid", "1");
            cmdinsert.Parameters.AddWithValue("@regdate", dateBooking.Text);
            cmdinsert.ExecuteNonQuery();
        }

        private void txtweight_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpkg_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                dateBooking.Focus();
            }
        }
        //public bool record()
        //{
        //    SqlCommand cmd=new SqlCommand("select * from customers where

        //}



    }
}
