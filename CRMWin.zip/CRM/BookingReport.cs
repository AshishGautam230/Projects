﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Diagnostics;

namespace CRM
{
    public partial class BookingReport : Form
    {
        public BookingReport()
        {
            InitializeComponent();
        }

        private void BookingReport_Load(object sender, EventArgs e)
        {
            {
                SqlCommand com = new SqlCommand("SELECT Status FROM BookingStatus", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                ddlStatus.Items.Add("All");
                while (reader.Read())
                {
                    ddlStatus.Items.Add(reader["Status"].ToString());
                }
                reader.Close();
                if (ddlStatus.Items.Count > 0)
                {
                    ddlStatus.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Boy FROM PickUpBoys", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                ddlPickupBoy.Items.Add("All");
                while (reader.Read())
                {
                    ddlPickupBoy.Items.Add(reader["Boy"].ToString());
                }
                reader.Close();
                if (ddlPickupBoy.Items.Count > 0)
                {
                    ddlPickupBoy.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Vendor FROM Vendors", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                ddlVendor.Items.Add("All");
                while (reader.Read())
                {
                    ddlVendor.Items.Add(reader["Vendor"].ToString());
                }
                reader.Close();
                if (ddlVendor.Items.Count > 0)
                {
                    ddlVendor.SelectedIndex = 0;
                }
            }
            {
                SqlCommand com = new SqlCommand("SELECT Network FROM Networks", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                ddlNetwork.Items.Add("All");
                while (reader.Read())
                {
                    ddlNetwork.Items.Add(reader["Network"].ToString());
                }
                reader.Close();
                if (ddlNetwork.Items.Count > 0)
                {
                    ddlNetwork.SelectedIndex = 0;
                }
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            string commandText = "SELECT * FROM Booking WHERE BookingDate BETWEEN '" + dateFrom.Text + "' AND '" + dateTo.Text + "' ";
            if (ddlNetwork.Text != "All")
            {
                commandText += " AND Agency='" + ddlNetwork.Text + "'";
            }

            if (ddlPickupBoy.Text != "All")
            {
                commandText += " AND PickUpBoy='" + ddlPickupBoy.Text + "'";
            }

            if (ddlStatus.Text != "All")
            {
                commandText += " AND Status='" + ddlStatus.Text + "'";
            }

            if (ddlVendor.Text != "All")
            {
                commandText += " AND Vendor='" + ddlVendor.Text + "'";
            }

            SqlCommand com = new SqlCommand(commandText, Methods.GetConnection());
            SqlDataReader reader = com.ExecuteReader();
            StreamWriter writer = new StreamWriter(new FileStream("BookingReport.html", FileMode.Create, FileAccess.Write));

            string HtmlReport = "<html><head> <title>Booking Report</title><script>function printreport(){ document.getElementById(\"btnPrint\").style.display = \"none\"; window.print();}</script></head><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px;\">" +
                "<table width=\"100%\"><tr><td colspan=\"2\" align=\"left\"><img src=\"CRMEx-Email.png\" alt=\"CRM-AppEx\" /></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td colspan=\"2\">" +
                "<br/><div  style=\"align:left; border-radius: 5px; border: 1px solid gray;\">" +
                "<table style=\"width:100%; font-size: 11; font-weight: bold; \">" +
                "<tr style=\"background-color: #BDDEFF \"><td>AWB No.</td><td>Date</td><td>Party Name</td><td>Contact</td><td>EMail</td><td>For. No.</td><td>Vendor</td><td>Network</td><td>Source</td><td>Destination</td><td>Amount</td><td>PickUp Boy</td><td>Status</td></tr>";
            while (reader.Read())
            {
                HtmlReport += "<tr><td>" + reader["AwbNo"].ToString() + "</td><td>" + reader["BookingDate"].ToString() + "</td><td>" + reader["PartyName"].ToString() + "</td><td>" + reader["Contact"].ToString() + "</td><td>" + reader["EMail"].ToString() + "</td><td>" + reader["ForwardingNo"].ToString() + "</td><td>" + reader["Vendor"].ToString() + "</td><td>" + reader["Agency"].ToString() + "</td><td>" + reader["Source"].ToString() + "</td><td>" + reader["Destination"].ToString() + "</td><td>" + reader["Amount"].ToString() + "</td><td>" + reader["PickUpBoy"].ToString() + "</td><td>" + reader["Status"].ToString() + "</td></tr>";
            }
            reader.Close();

            HtmlReport += "</table>"
             +
                 "</div><br/><center><input type=\"button\" id=\"btnPrint\" value=\"Print\" onclick=\"printreport()\" /></center><br/><div style=\"background-color:#6AAEFA; height: 10px;\" /><br/></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">" + Methods.CompanyName + "<br/>" + Methods.CompanyContact + "<br/>" + Methods.CompanyEmail + "</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
                 "Powered By: <a href=\"http://www.whiteapplecorp.com\">WhiteApple Software Services</a></p></td></tr></table></div></center></body></html>";
            writer.Write(HtmlReport);
            writer.Close();
            Process.Start("BookingReport.html");

        }
    }
}
