﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRM
{
    public partial class ListQueries : Form
    {
        public ListQueries()
        {
            InitializeComponent();
        }

        void GetQueries()
        {
            lstQueries.Items.Clear();
            SqlCommand com;
            if (Methods.IsAdmin)
            {
                com = new SqlCommand("SELECT C.CustomerName, C.Contact, C.EMail, Q.QueryID, Q.QID, Q.CustomerID, Q.QDate, Q.Query, Q.Query, Q.QType, Q.Status FROM Customers C, Queries Q WHERE Q.CustomerID = C.CustomerID AND Q.Status = 'Follow Up Needed' AND Q.QDate <= @Date", Methods.GetConnection());
            }
            else
            {
                com = new SqlCommand("SELECT C.CustomerName, C.Contact, C.EMail, Q.QueryID,  Q.QID,Q.CustomerID, Q.QDate, Q.Query, Q.QType, Q.Status FROM Customers C, Queries Q WHERE Q.CustomerID = C.CustomerID AND Q.Status = 'Follow Up Needed' AND Q.QDate <= @Date AND Q.UserID=@UserID", Methods.GetConnection());
                com.Parameters.AddWithValue("@UserID", Methods.UserID);
            }
            com.Parameters.AddWithValue("@Date", dateTimePicker1.Value.ToShortDateString());
            DataTable dt = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(com);
            ad.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                ListViewItem i = lstQueries.Items.Add(row["QID"].ToString());
                i.SubItems.Add(row["QDate"].ToString().Substring(0, 10));
                i.SubItems.Add(row["CustomerID"].ToString());
                i.SubItems.Add(row["CustomerName"].ToString());
                i.SubItems.Add(row["Contact"].ToString());
                i.SubItems.Add(row["EMail"].ToString());
                i.SubItems.Add(row["Query"].ToString());
                i.SubItems.Add(row["QueryID"].ToString());
                i.SubItems.Add(row["QType"].ToString());
                i.SubItems.Add(row["Status"].ToString());
            }
        }

        private void ListQueries_Load(object sender, EventArgs e)
        {
            GetQueries();
        }

        private void lstQueries_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lstQueries.SelectedItems.Count != 0)
            {
                new UpdateQuery(Convert.ToInt32(lstQueries.SelectedItems[0].SubItems[7].Text), lstQueries.SelectedItems[0].Text, Convert.ToInt32(lstQueries.SelectedItems[0].SubItems[2].Text), lstQueries.SelectedItems[0].SubItems[3].Text, lstQueries.SelectedItems[0].SubItems[6].Text, lstQueries.SelectedItems[0].SubItems[8].Text, lstQueries.SelectedItems[0].SubItems[9].Text).ShowDialog();
                GetQueries();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            GetQueries();
        }
    }
}
