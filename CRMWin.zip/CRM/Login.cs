﻿namespace CRM
{
    using System;
    using System.Windows.Forms;
    using Microsoft.Win32;
    using System.Data.SqlClient;
    using System.Diagnostics;

    public partial class Login : Form
    {
        int UserType;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
          
        }
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("UserLogin", Methods.GetConnection());
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@UserName", txtUserName.Text);
            com.Parameters.AddWithValue("@Password", txtPassword.Text);
            com.Parameters.AddWithValue("@UserType", 100).Direction = System.Data.ParameterDirection.Output;
            com.Parameters.AddWithValue("@UserID", 0).Direction = System.Data.ParameterDirection.Output;
            com.ExecuteNonQuery();
            if (com.Parameters["@UserType"].Value != DBNull.Value)
            {
                Methods.IsAdmin = (Convert.ToInt32(com.Parameters["@UserType"].Value) == 1) ? true : false;
                if (UserType != 100)
                {
                    lblProgress.Visible = true;
                    btnLogin.Enabled = txtPassword.Enabled = txtUserName.Enabled = false;
                    Methods.UserID = Convert.ToInt32(com.Parameters["@UserID"].Value);
                    Methods.UserName = txtUserName.Text.ToLower();
                    tmrLogin.Start();
                }
                else
                {
                    MessageBox.Show("Invalid username or password!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }


        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                e.Handled = true;
                SqlCommand com = new SqlCommand("UserLogin", Methods.GetConnection());
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@UserName", txtUserName.Text);
                com.Parameters.AddWithValue("@Password", txtPassword.Text);
                com.Parameters.AddWithValue("@UserType", 100).Direction = System.Data.ParameterDirection.Output;
                com.Parameters.AddWithValue("@UserID", 0).Direction = System.Data.ParameterDirection.Output;
                com.ExecuteNonQuery();
                if (com.Parameters["@UserType"].Value != DBNull.Value)
                {
                    Methods.IsAdmin = (Convert.ToInt32(com.Parameters["@UserType"].Value) == 1) ? true : false;
                    if (UserType != 100)
                    {
                        lblProgress.Visible = true;
                        btnLogin.Enabled = txtPassword.Enabled = txtUserName.Enabled = false;
                        Methods.UserID = Convert.ToInt32(com.Parameters["@UserID"].Value);
                        Methods.UserName = txtUserName.Text.ToLower();                        
                        tmrLogin.Start();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        private void tmrLogin_Tick(object sender, EventArgs e)
        {
            this.Hide();
            lblProgress.Visible = false;
            new CRM().Show();
            tmrLogin.Stop();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}
