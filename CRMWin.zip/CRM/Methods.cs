﻿namespace CRM
{
    using System.Configuration;
    using System.Data.SqlClient;
    class Methods
    {
        public static int UserID {get; set;}
        public static int CustomerID { get; set; }
        public static string UserName { get; set; }
        public static string CompanyName { get; set; }
        public static bool IsAdmin { get; set; }
        public static string CustomerEmail { get; set; }
        public static string CompanyEmail { get; set; }
        public static string CompanyContact { get; set; }
     
        public static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            if (con.State != System.Data.ConnectionState.Open)
            {
                con.Open();
            }
            return con;
        }


        public static string trackurl(string network, string fwdno)
        {
            string fwdnetwork = network.ToUpper() ;
            string url="";
            if (fwdnetwork.Equals("DHL"))
            {
                url = "http://www.dhl.com/cgi-bin/tracking.pl?TID=CP_IND&FIRST_DB=&awb=" + fwdno;
            }
            else if (fwdnetwork.Equals("FEDEX"))
            {
                url="http://www.fedex.com/Tracking?clienttype=dotcom&initial=n&ascend_header=1&sum=n&cntry_code=us&language=english&tracknumber_list=" + fwdno;
            }
            else if (fwdnetwork.Equals("TNT"))
            {
               url= "http://www.tnt.com/webtracker/tracking.do#" + fwdno;

            }
            else if (fwdnetwork.Equals("ARAMEX"))
            {
                url="http://www.aramex.com/track_results_multiple.aspx?ShipmentNumber=" + fwdno;
            }
            else if (fwdnetwork.Equals("UPS"))
            {
                url = "http://wwwapps.ups.com/WebTracking/track?HTMLVersion=5.0&loc=en_IN&Requester=UPSHome&WBPM_lid=homepage%2Fct1.html_pnl_trk&trackNums=" + fwdno;
            }
            else if (fwdnetwork.Equals("UBX"))
            {
                url="http://www.ubxpress.in/TrackDetails.asp?afno=" + fwdno;
            }
            else if (fwdnetwork.Equals("BOMBINO"))
            {
                url = "http://www.bombinoexp.com/Tracking.aspx?txtAwb=" + fwdno;
            }
            return url;
        }

    }
}
