﻿namespace CRM
{
    using System;
    using System.Windows.Forms;
    using System.Data.SqlClient;
    public partial class CRM : Form
    {
        public CRM()
        {
            InitializeComponent();
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void customerRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerRegistration obj = new CustomerRegistration();
            obj.MdiParent = this;
            obj.Show();
        }

        void myTaskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListQueries obj = new ListQueries();
            obj.MdiParent = this;
            obj.Show();
        }


        private void queryRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QueryRegistration obj = new QueryRegistration();
            obj.MdiParent = this;
            obj.Show();
        }

        private void searchQueriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchQuery obj = new SearchQuery();
            obj.MdiParent = this;
            obj.Show();
        }

        private void createUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateUser obj = new CreateUser();
            obj.MdiParent = this;
            obj.Show();
        }

        private void myProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyProfile obj = new MyProfile();
            obj.MdiParent = this;
            obj.Show();
            
        }

        private void CRM_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void userReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserReport obj = new UserReport();
            obj.MdiParent = this;
            obj.Show();
        }

        private void CRM_Load(object sender, EventArgs e)
        {
            createUserToolStripMenuItem.Visible = Methods.IsAdmin;
            SqlCommand com = new SqlCommand("SELECT CompanyName, Contact, EMail FROM CompanyInfo", Methods.GetConnection());
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                Methods.CompanyName = reader[0].ToString();
                Methods.CompanyContact = reader[1].ToString();
                Methods.CompanyEmail = reader[2].ToString();
            }
            reader.Close();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SqlCommand com = new SqlCommand("UPDATE Users SET Password=@Password WHERE UserID=@UserID", Methods.GetConnection());
            com.Parameters.AddWithValue("@UserID", Methods.UserID);
            string password = Microsoft.VisualBasic.Interaction.InputBox("Enter new password:", "Change Password");
            com.Parameters.AddWithValue("@Password", password);
            if (!string.IsNullOrEmpty(password))
            {
                com.ExecuteNonQuery();
                MessageBox.Show("Password successfully changed!", "CRM AppEx", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }

        }

        private void bookingEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookingEntry obj = new BookingEntry();
            obj.MdiParent = this;
            obj.Show();
        }

        private void searchBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchBooking obj = new SearchBooking();
            obj.MdiParent = this;
            obj.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About obj = new About();
            obj.MdiParent = this;
            obj.Show();
        }

        private void bookingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookingReport obj = new BookingReport();
            obj.MdiParent = this;
            obj.Show();
        }

        private void sendSMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SendSMS sms = new SendSMS();
            sms.Show();
            sms.MdiParent = this;
        }

        private void billingReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClientBilling cbl = new ClientBilling();
            cbl.MdiParent = this;
            cbl.Show();

        }

        private void logisticBillingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //CargoBilling crb = new CargoBilling();
            ClientBilling crb = new ClientBilling();
            crb.MdiParent = this;
            crb.Show();
        }

        private void openExistingBillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenPreviousBill opb = new OpenPreviousBill();
            opb.MdiParent = this;
            opb.Show();
        }

        private void sMSToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
