﻿namespace CRM
{
    using System;
    using System.Windows.Forms;
    using Microsoft.Win32;
    using System.Data.SqlClient;

    public partial class CreateUser : Form
    {
        public CreateUser()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("INSERT INTO Users (UserName, Password, UserType) VALUES (@UserName, @Password, @UserType)", Methods.GetConnection());
            com.Parameters.AddWithValue("@UserName", txtUser.Text);
            com.Parameters.AddWithValue("@Password", txtPass.Text);
            com.Parameters.AddWithValue("@UserType", (chkAdmin.Checked)? 1: 0);
            if (com.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("User " + txtUser.Text + " created!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("User " + txtUser.Text + " already exists!", "CRM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtPass.Focus();
            }
        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtConfirmPass.Focus();
            }
        }

        private void txtConfirmPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnCreate.Focus();
            }
        }
    }
}
