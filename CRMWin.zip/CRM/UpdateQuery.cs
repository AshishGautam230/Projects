﻿namespace CRM
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Windows.Forms;
    public partial class UpdateQuery : Form
    {
        public UpdateQuery()
        {
            InitializeComponent();
            ddlResolution.SelectedIndex = 1;
        }

        private void btnUpdateQuery_Click(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("UpdateQuery", Methods.GetConnection());
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@QueryID", this.QueryID);
            com.Parameters.AddWithValue("@QID", this.QID);
            com.Parameters.AddWithValue("@Status", ddlResolution.Text);
            com.Parameters.AddWithValue("@Remark", ddlResolution.Text + " : " + txtRemark.Text);
            com.Parameters.AddWithValue("@FollowUPDate", dateFollowUp.Value.ToShortDateString());
            com.Parameters.AddWithValue("@CustomerID", this.CustomerID);
            com.Parameters.AddWithValue("@UserID", Methods.UserID);
            com.ExecuteNonQuery();
            MessageBox.Show("Status Updated!");
            this.Close();
        }


        public UpdateQuery(int QueryID, string QID, int CustomerID, string CustomerName, string Query, string QueryType, string Status)
        {
            InitializeComponent();
            this.QueryID = QueryID;
            lblQueryID.Text = (this.QID = QID).ToString();
            lblCustomerID.Text = (this.CustomerID = CustomerID).ToString();
            lblCustomerName.Text = this.CustomerName = CustomerName;
            txtQuery.Text = this.Query = Query;
            lblQTyp.Text = this.QueryType = QueryType;
            ddlResolution.Text = this.Status = Status;
            //this.QueryID = QueryID;
            //lblQueryID.Text = (this.QID = QID).ToString();
            //lblCustomerID.Text = (this.CustomerID = CustomerID).ToString();
            //lblCustomerName.Text = this.CustomerName = CustomerName;
            //txtQuery.Text = this.Query = Query;
            //lblQueryTyp.Text = this.QueryType = QueryType;
            //ddlResolution.Text = this.Status = Status;
        }

        private void UpdateQuery_Load(object sender, EventArgs e)
        {

        }

        private void UpdateQuery_Load_1(object sender, EventArgs e)
        {

        }
    }
}
