﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRM
{
    public partial class SearchCustomer : Form
    {
        public SearchCustomer()
        {
            InitializeComponent();
        }

        private void SearchCustomer_Load(object sender, EventArgs e)
        {
            ddlSearch.SelectedIndex = 0;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lstSearch.Items.Clear();
            SqlCommand com = new SqlCommand("SELECT CustomerID, CustomerName, Contact, EMail FROM Customers WHERE "+ddlSearch.Text +" like '"+txtSearch.Text+"%'", Methods.GetConnection());
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(com);
            adt.Fill(dt);
            foreach(DataRow row in dt.Rows)
            {
                ListViewItem i = lstSearch.Items.Add(row["CustomerID"].ToString());
                i.SubItems.Add(row["CustomerName"].ToString());
                i.SubItems.Add(row["Contact"].ToString());
                i.SubItems.Add(row["Email"].ToString());                
            }

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            lstSearch.Items.Clear();
            SqlCommand com = new SqlCommand("SELECT CustomerID, CustomerName, Contact, EMail FROM Customers WHERE " + ddlSearch.Text + " like '" + txtSearch.Text + "%'", Methods.GetConnection());
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(com);
            adt.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                ListViewItem i = lstSearch.Items.Add(row["CustomerID"].ToString());
                i.SubItems.Add(row["CustomerName"].ToString());
                i.SubItems.Add(row["Contact"].ToString());
                i.SubItems.Add(row["Email"].ToString());
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Methods.CustomerID = Convert.ToInt32(lstSearch.SelectedItems[0].Text);
            Methods.CustomerEmail = lstSearch.SelectedItems[0].SubItems[3].Text;
            this.Close();
        }
    }
}
