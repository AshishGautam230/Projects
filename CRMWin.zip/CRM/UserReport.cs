﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace CRM
{
    public partial class UserReport : Form
    {
        public UserReport()
        {
            InitializeComponent();
        }

        private void UserReport_Load(object sender, EventArgs e)
        {
            if (Methods.IsAdmin)
            {
                SqlCommand com = new SqlCommand("SELECT UserID, UserName FROM Users", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    cmbUser.Items.Add(reader["UserID"].ToString() + " : " + reader["UserName"].ToString());
                }
                reader.Close();
                if (cmbUser.Items.Count > 0)
                {
                    cmbUser.SelectedIndex = 0;
                }
            }
            else
            {
                lblUser.Visible = cmbUser.Visible = false;
            }
        }



        private void btnReport_Click(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("GetUserReport", Methods.GetConnection());
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@UserID", ((Methods.IsAdmin) ? Convert.ToInt32(cmbUser.Text.Substring(0, cmbUser.Text.IndexOf(' '))) : Methods.UserID));
            com.Parameters.AddWithValue("@DateFrom", dateFrom.Value.ToShortDateString());
            com.Parameters.AddWithValue("@DateTo", dateTo.Value.ToShortDateString());
            com.Parameters.AddWithValue("@TotalCustomers", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@Total", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@Resolved", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@Cancelled", 0).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@TotalCalls", 0).Direction = ParameterDirection.Output;
            com.ExecuteNonQuery();
            string TotalCustomers = com.Parameters["@TotalCustomers"].Value.ToString();
            string TotalQueries = com.Parameters["@Total"].Value.ToString();
            string ResolvedQueries = com.Parameters["@Resolved"].Value.ToString();
            string CancelledQueries = com.Parameters["@Cancelled"].Value.ToString();
            string TotalCalls = com.Parameters["@TotalCalls"].Value.ToString();

            StreamWriter writer = new StreamWriter(new FileStream("UserReport.html", FileMode.Create, FileAccess.Write));
            if (Methods.IsAdmin)
            {
                writer.Write(GenerateReport(cmbUser.Text.Split(':')[1], TotalCustomers, TotalQueries, ResolvedQueries, CancelledQueries, TotalCalls, dateFrom.Value.ToShortDateString(), dateTo.Value.ToShortDateString()));
            }
            else
            {
                writer.Write(GenerateReport(Methods.UserName, TotalCustomers, TotalQueries, ResolvedQueries, CancelledQueries, TotalCalls, dateFrom.Value.ToShortDateString(), dateTo.Value.ToShortDateString()));
            }
            writer.Close();
            Process.Start("UserReport.html");

        }

        string GenerateReport(string UserName, string TotalCustomer, string TotalQueries, string ResolvedQueries, string CancelledQueries, string TotalCalls, string FromDate, string ToDate)
        {
            string HtmlReport = "<html><head> <title>User Report</title></head><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px;\">" +
                "<table width=\"100%\"><tr><td colspan=\"2\" align=\"left\"><img src=\"CRMEx-Email.png\" alt=\"CRM-AppEx\" /></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td colspan=\"2\">" +
                "<div  style=\"align:left;\">" +
                "<table style=\"width:100%; font-size: 11; font-weight: bold; \">"

                + "<tr><td align=\"right\" style=\"width:50%\">UserName:</td><td align=\"left\" style=\"width:50%\">" + UserName + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">From Date:</td><td align=\"left\" style=\"width:50%\">" + FromDate + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">To Date:</td><td align=\"left\" style=\"width:50%\">" + ToDate + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">Total New Customers:</td><td align=\"left\" style=\"width:50%\">" + TotalCustomer + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">Total Calls:</td><td align=\"left\" style=\"width:50%\">" + TotalCalls + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">Total Queries:</td><td align=\"left\" style=\"width:50%\">" + TotalQueries + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">Total Queries Resolved:</td><td align=\"left\" style=\"width:50%\">" + ResolvedQueries + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:50%\">Total Queries Cancelled:</td><td align=\"left\" style=\"width:50%\">" + CancelledQueries + "</td></tr>" +
                
                "</table>"
                +
                    "</div><br/><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">"+Methods.CompanyName+"<br/>"+Methods.CompanyContact+"<br/>"+Methods.CompanyEmail+"</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
                    "Powered By: <a href=\"http://www.whiteapplecorp.com\">WhiteApple Software Services</a></p></td></tr></table></div></center></body></html>";

            return HtmlReport;
        }

    }
}
