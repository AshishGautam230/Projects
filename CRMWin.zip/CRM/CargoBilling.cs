﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
using System.IO;
using System.Diagnostics;


namespace CRM
{
    public partial class CargoBilling : Form
    {
        float agency, chamot, gsp, wtdiff, customduty, documentation, repacking, misc, marking, fork, cmccha, dcc, transportation, aai, measurment, airfreight, billoflading, tr6, aaiwt, damurrage, docharges, loading, container, chargesairlines,adc,lisc;
        float totaltaxable, taxpercent, totalnontaxable,grandtaxable,totaldue,taxamount;
        public CargoBilling()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
        public void calculate()
        {
            //agency, chamot, gsp, wtdiff, customduty, documentation, repacking, misc, marking, fork, cmccha, dcc, transportation, aai, measurment, airfreight, billoflading, tr6, aaiwt, damurrage, docharges, loading, container,chargesairlines;
            
          //TAXABLE CHARGES

            agency = Convert.ToSingle(txtAgency.Text);
            chamot = Convert.ToSingle(txtCha.Text);
            gsp = Convert.ToSingle(txtGsp.Text);
            wtdiff = Convert.ToSingle(txtWtDiff.Text);
            customduty = Convert.ToSingle(txtCustomDuty.Text);
            documentation = Convert.ToSingle(txtDocumentation.Text);
            repacking = Convert.ToSingle(txtRepacking.Text);
            misc = Convert.ToSingle(txtMisc.Text);
            marking = Convert.ToSingle(txtMarking.Text);
            fork = Convert.ToSingle(txtFork.Text);
            cmccha = Convert.ToSingle(txtCmcCha.Text);
            dcc = Convert.ToSingle(txtDcc.Text);
            transportation = Convert.ToSingle(txtTransportation.Text);
            adc = Convert.ToSingle(txtAdc.Text);
            lisc = Convert.ToSingle(txtLisc.Text);

            totaltaxable = agency + chamot + gsp + wtdiff + customduty + documentation + repacking + misc + marking + fork + cmccha + dcc + transportation+adc+lisc;

            taxpercent=Convert.ToSingle(txtTaxPercent.Text);
            taxamount = totaltaxable * taxpercent / 100;
            txtTaxAmount.Text = taxamount.ToString("N2");
            grandtaxable = totaltaxable + taxamount;
            txtGrandTaxable.Text = grandtaxable.ToString("N2");


            //float 
            txtTotalTaxable.Text = totaltaxable.ToString("N2");
            

         //NON TAXABLE CHARGES
            aai = Convert.ToSingle(txtAai.Text);
            measurment = Convert.ToSingle(txtMeasurement.Text);
            airfreight = Convert.ToSingle(txtAirFreight.Text);
            billoflading = Convert.ToSingle(txtBillLading.Text);
            tr6 = Convert.ToSingle(txtTR6.Text);
            aaiwt = Convert.ToSingle(txtAAIWT.Text);
            damurrage = Convert.ToSingle(txtDamurrage.Text);
            docharges = Convert.ToSingle(txtDOCharges.Text);
            loading = Convert.ToSingle(txtLoading.Text);
            container = Convert.ToSingle(txtContainer.Text);
            chargesairlines = Convert.ToSingle(txtChargesAirlines.Text);

            totalnontaxable = aai + measurment + airfreight + billoflading + tr6 + aaiwt + damurrage + docharges + loading + container + chargesairlines;


            txtNonTax.Text = totalnontaxable.ToString("N2");

            totaldue = grandtaxable + totalnontaxable;
            txtTotalDue.Text = totaldue.ToString("N2");
            






            

        }

        private void CargoBilling_Load(object sender, EventArgs e)
        {
            txtPartyName.Focus();
            SqlCommand com = new SqlCommand("select customername from customers order by customername asc", Methods.GetConnection());
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                txtPartyName.Items.Add(reader["customername"].ToString().Trim());
            }
            

        }

        private void txtPartyName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPartyName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPortName.Focus();
            }

        }

        private void txtPortName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtMawbNo.Focus();
            }
        }

        private void txtMawbNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtHawbNo.Focus();
            }
        }

        private void txtHawbNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                billDate.Focus();
            }
        }

        private void billDate_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtBeNo.Focus();
                
            }
        }

        private void txtBeNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtPkt.Focus();

            }
        }

        private void txtPkt_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtWt.Focus();
            }
        }

        private void txtWt_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtMaterial.Focus();
            }
        }

        private void txtMaterial_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtInvoice.Focus();
            }
        }

        private void txtInvoice_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
            //    txtAgency.Focus();
                txtShipperRef.Focus();

            }
        }

        private void txtAgency_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtCha.Focus();
            }
        }

        private void txtCha_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtGsp.Focus();
            }
        }

        private void txtGsp_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtWtDiff.Focus();

            }
        }

        private void txtWtDiff_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtCustomDuty.Focus();

            }
        }

        private void txtCustomDuty_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtDocumentation.Focus();
            }
        }

        private void txtDocumentation_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtRepacking.Focus();
            }
        }

        private void txtRepacking_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtMisc.Focus();
            }
        }

        private void txtMisc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtMarking.Focus();
            }
        }

        private void txtMarking_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtFork.Focus();
            }
        }

        private void txtFork_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtCmcCha.Focus();
            }
        }

        private void txtCmcCha_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtDcc.Focus();
            }
        }

        private void txtDcc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtTransportation.Focus();

            }
        }

        private void txtTransportation_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                //txtAai.Focus();
                txtAdc.Focus();
            }
        }

        private void txtAai_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtMeasurement.Focus();
            }
        }

        private void txtMeasurement_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtAirFreight.Focus();
            }
        }

        private void txtAirFreight_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtBillLading.Focus();
            }
        }

        private void txtBillLading_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtTR6.Focus();

            }
        }

        private void txtTR6_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtAAIWT.Focus();
            }
        }

        private void txtAAIWT_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtDamurrage.Focus();
            }
        }

        private void txtDamurrage_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtDOCharges.Focus();

            }
        }

        private void txtDOCharges_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                txtLoading.Focus();
            }
        }

        private void txtLoading_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtContainer.Focus();

            }
        }

        private void txtContainer_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                //button1.Focus();
                txtChargesAirlines.Focus();
            }
        }
        public void reset()
        {
            txtPartyName.Text = txtPortName.Text = txtMawbNo.Text = txtHawbNo.Text = txtBeNo.Text = txtPkt.Text = txtWt.Text = txtMaterial.Text = txtInvoice.Text = txtAgency.Text = txtCha.Text = txtGsp.Text = txtWt.Text = txtCustomDuty.Text = txtDocumentation.Text = txtRepacking.Text = txtMisc.Text = txtMarking.Text = txtFork.Text = txtCmcCha.Text = txtDcc.Text = txtTransportation.Text = txtAai.Text = txtMeasurement.Text = txtAirFreight.Text = txtBillLading.Text = txtTR6.Text = txtAAIWT.Text = txtDamurrage.Text = txtDOCharges.Text = txtLoading.Text = txtContainer.Text = string.Empty;


        }

        private void txtChargesAirlines_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            calculate();
            SqlCommand cmdcustomerdetails = new SqlCommand("select customername,address,contact,email from customers where customername=@cname", Methods.GetConnection());
            cmdcustomerdetails.Parameters.AddWithValue("@cname", txtPartyName.Text);
            SqlDataReader sdrcmdetails = cmdcustomerdetails.ExecuteReader();
            sdrcmdetails.Read();
            string customername = sdrcmdetails["customername"].ToString();
            string customeraddress = sdrcmdetails["address"].ToString();
            string customerphone = sdrcmdetails["contact"].ToString();
            string customeremail = sdrcmdetails["email"].ToString();

            string filename = txtInvoice.Text + ".html";

            StreamWriter writer = new StreamWriter(new FileStream(filename, FileMode.Create, FileAccess.Write));
            string HtmlReport = "<html><head> <title>Billing Report</title><script>function printreport(){ document.getElementById(\"btnPrint\").style.display = \"none\"; window.print();}</script></head><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px; height:1180px\">" +
                "<table width=\"100% \"><tr><td colspan=\"2\" align=\"left\"><img src=\"headerjns.png\" height=80 width=860></img></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr \"width=860px\"><td \"width=30%\" colspan=\"1\"><div style=\"height:120px;width:250px;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold\">Billed To:<br/><table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td>Name :" + customername + "</td></tr><tr><td>Address :" + customeraddress + "</td></tr><tr><td>Phone :" + customerphone + "</td></tr><tr><td>Email :" + customeremail + "</td></tr></table></div></td><td colspan=\"1\" \"width=70%\"><div style=\"height:100%;width:100%;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold; float:right;\">Invoice Details:<table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td width=\"50%\">Invoice Date:"+ billDate.Value.ToShortDateString() +"</td>"+"<td width=\"50%\"> Port: "+txtPortName.Text + "</td></tr><tr><td width=\"50%\">Invoice No. :" + txtInvoice.Text + "</td><td width=\"50%\">MAWB NO. & DT. : " + txtMawbNo.Text + "</td></tr><tr><td width=\"50%\">From Date:" + billDate.Value.ToShortDateString() + "</td><td width=\"50%\">HAWB NO. & DT. :" + txtHawbNo.Text + "</td></tr><tr><td width=\"50%\">Date To:" + billDate.Value.ToShortDateString() + "</td><td width=\"50%\">BE/SB NO. & DT. : "+ txtBeNo.Text + "</td></tr><tr><td width=\"50%\">Material :"+ txtMaterial.Text + "</td><td width=\"50%\">Package/Weight:" + txtPkt.Text + "/" + txtWt.Text + "</td></tr><tr><td width=\"50%\">Shipper Ref. No." + txtShipperRef.Text + "</td></tr></table></div></td></tr><td colspan=\"2\">" +
                                  "<br/><div  style=\"align:left; border-radius: 5px; border: 1px solid gray;\">" +
                                  "<table style=\"font-size: 11; font-weight: bold; float:right; width:100%; height:700px; border:1px solid gray; border-radius:5px;float:right\" >" +
                                  "<tr style=\"background-color: #BDDEFF \"><td>Serial No.</td><td>TAXABLE UNDER SERVICE TAX</td><td style=\"text-align:right; margin-right:6px\">Amount</td></tr>";
            HtmlReport += "<tr><td>1.</td><td>AGENCY</td><td style=\"text-align:right; margin-right:6px\">" + agency.ToString("N2") + "</td></tr>" + "<tr><td>2.</td><td>CHA MOT / W/L NOC</td><td style=\"text-align:right; margin-right:6px\">" + chamot.ToString("N2") + "</td></tr>" + "<tr><td>3.</td><td>GSP / DCC</td><td style=\"text-align:right; margin-right:6px\">" + gsp.ToString("N2") + "</td></tr>" + "<tr><td>4.</td><td>WT. DIFF AMT</td><td style=\"text-align:right; margin-right:6px\">" + wtdiff.ToString("N2") + "</td></tr>" + "<tr><td>5.</td><td>CUSTOM DUTY</td><td style=\"text-align:right; margin-right:6px\">" + customduty.ToString("N2") + "</td></tr>" + "<tr><td>6.</td><td>DOCUMENTATION</td><td style=\"text-align:right; margin-right:6px\">" + documentation.ToString("N2") + "</td></tr>" + "<tr><td>7.</td><td>OPEN & RE-PACKING +STRAPPING</td><td style=\"text-align:right; margin-right:6px\">" + repacking.ToString("N2") + "</td></tr>" + "<tr><td>8.</td><td>MISC CH.(APRAISING)</td><td style=\"text-align:right; margin-right:6px\">" + misc.ToString("N2") + "</td></tr>" + "<tr><td>9.</td><td>WITHOUT MARKING & LABELING</td><td style=\"text-align:right; margin-right:6px\">" + marking.ToString("N2") + "</td></tr>" + "<tr><td>10.</td><td>FORK/CRANE CH./CTG CH.</td><td style=\"text-align:right; margin-right:6px\">" + fork.ToString("N2") + "</td></tr>" + "<tr><td>11.</td><td>CMC CHA.</td><td style=\"text-align:right; margin-right:6px\">" + cmccha.ToString("N2") + "</td></tr>" + "<tr><td>12.</td><td>DCC+MINISTRY + LEAGLISATION</td><td style=\"text-align:right; margin-right:6px\">" + dcc.ToString("N2") + "</td></tr>" + "<tr><td>13.</td><td>TRANSPORTATION/LOADING/UNLOADING</td><td style=\"text-align:right; margin-right:6px\">" + transportation.ToString("N2") + "</td></tr><tr><td>14.</td><td>ADC PROCESSING CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + adc.ToString("N2") + "</td></tr><tr><td>15.</td><td>LICENSE PROCESSING CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + lisc.ToString("N2") + "</td></tr>" + "<tr style=\"background-color: #BDDEFF \"><td>Serial No.</td><td>NON TAXABLE</td><td style=\"text-align:right; margin-right:6px\">Amount</td></tr>" + "<tr><td>1.</td><td>AAI CH./CWC CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + aai.ToString("N2") + "</td></tr>" + "<tr><td>2.</td><td>MEASUREMENT CH.</td><td style=\"text-align:right; margin-right:6px\">" + measurment.ToString("N2") + "</td></tr>" + "<tr><td>3.</td><td>AIR FRT/SEA FRT.</td><td style=\"text-align:right; margin-right:6px\">" + airfreight.ToString("N2") + "</td></tr>" + "<tr><td>4.</td><td>BILL OF LANDING.</td><td style=\"text-align:right; margin-right:6px\">" + billoflading.ToString("N2") + "</td></tr>" + "<tr><td>5.</td><td>TR-6 CHALLN</td><td style=\"text-align:right; margin-right:6px\">" + tr6.ToString("N2") + "</td></tr>" + "<tr><td>6.</td><td >AAI WT DIFF TC. CH.</td><td style=\"text-align:right; margin-right:6px\">" + wtdiff.ToString("N2") + "</td></tr>" + "<tr><td>7.</td><td>AAI DAMURRAGE OR PANELTY </td><td style=\"text-align:right; margin-right:6px\">" + damurrage.ToString("N2") + "</td></tr>" + "<tr><td>8.</td><td>DO CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + docharges.ToString("N2") + "</td></tr>" + "<tr><td>9.</td><td>LOADING UNLOADING</td><td style=\"text-align:right; margin-right:6px\">" + loading.ToString("N2") + "</td></tr>" + "<tr><td>10.</td><td>CONTAINER OUT RECT. CH. OF YARD TO PORT & PORT TO YARD</td><td style=\"text-align:right; margin-right:6px\">" + container.ToString("N2") + "</td></tr>" + "<tr><td>11.</td><td>CHARGES RECEIVED BY AIRLINE </td><td style=\"text-align:right; margin-right:6px\">" + chargesairlines.ToString("N2") + "</td></tr>";










            HtmlReport += "</table></div><br/><div style=\"float:left; width:70%; height:160px; border-radius:5px; border: 1px solid gray; margin-top:3px; margin-left:3px; font-size: 11px; font-weight: bold; font-family: Helvetica;\"><h3>TERMS & CONDITIONS</h3><p></br>E. & O.E. Interest @ 18% per annum is chargeable on bills not paid on presentation.</br>All disputes subject to Delhi Jurisdiction.</br>BANK DETAILS </br> PLEASE MAKE CHEQUE OR DD IN FAVOR OF JNS LOGISTICS PVT LTD.</br>   BANK NAME : KOTAK MAHINDRA BANK</br>A/C NO. :  9211476277</br>  IFSC :  KKBK0000193</p></div><div style=\"float:right; width:23%; height:160px;border-radius:5px;border: 1px solid gray; margin-right:3px; margin-top:3px\"><table style=\"font-size: 11px; font-weight: bold; font-family: Helvetica;\"><tr><td>Total Taxable Amount:</td><td style=\"text-align:right\">" + totaltaxable.ToString("N2") + "</td></tr><tr><td>Tax %</td><td style=\"text-align:right\">" + taxpercent.ToString() + "%" + "</td></tr><tr><td>Total Tax: </td><td style=\"text-align:right\">" + taxamount.ToString("N2") + "</td></tr></tr><tr><td>Grand Taxable: </td><td style=\"text-align:right\">" + grandtaxable.ToString("N2") + "</td></tr><tr><td>Total Non Taxable: </td><td style=\"text-align:right\">" + totalnontaxable.ToString("N2") + "</td></tr><tr><td></td><td><hr></td></tr><tr><td>Total Due Amount: </td><td style=\"text-align:right\">" + totaldue.ToString("N2") + "</td></tr></table></div></td></tr></table><br/><center><input type=\"button\" id=\"btnPrint\" value=\"Print\" onclick=\"printreport()\" /></center></td></tr><tr><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
                 "Report By: <a href=\"http://www.jnslog.com\">JNS Logistics Pvt. Ltd.</a></p></td></tr></table></div></center></body></html>";

            writer.Write(HtmlReport);
            writer.Close();
            Process.Start(filename);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*SqlCommand cmdcustomerdetails = new SqlCommand("select customername,address,contact,email from customers where customername=@cname", Methods.GetConnection());
            cmdcustomerdetails.Parameters.AddWithValue("@cname", txtPartyName.Text);
            SqlDataReader sdrcmdetails = cmdcustomerdetails.ExecuteReader();
            sdrcmdetails.Read();
            string customername = sdrcmdetails["customername"].ToString();
            string customeraddress = sdrcmdetails["address"].ToString();
            string customerphone = sdrcmdetails["contact"].ToString();
            string customeremail = sdrcmdetails["email"].ToString();

            string filename = txtInvoice.Text + ".html";

            StreamWriter writer = new StreamWriter(new FileStream(filename, FileMode.Create, FileAccess.Write));
            string HtmlReport = "<html><head> <title>Billing Report</title><script>function printreport(){ document.getElementById(\"btnPrint\").style.display = \"none\"; window.print();}</script></head><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px; height:1180px\">" +
                "<table width=\"100% \"><tr><td colspan=\"2\" align=\"left\"><img src=\"headerjns.png\" height=80 width=860></img></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr \"width=860px\"><td \"width=250px\" colspan=\"1\"><div style=\"height:120px;width:250px;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold\">Billed To:<br/><table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td>Name :" + customername + "</td></tr><tr><td>Address :" + customeraddress + "</td></tr><tr><td>Phone :" + customerphone + "</td></tr><tr><td>Email :" + customeremail + "</td></tr></table></div></td><td colspan=\"1\" \"width=250px\"><div style=\"height:120px;width:350px;border:1px solid #DDDDDD; border-radius: 5px;font-size:11px;font-family:helvetica; font-weight:bold; float:right;\">Invoice Details:<table style=\"font-size:11px;font-family:helvetica; font-weight:bold;\"><tr><td>Invoice Date:</td><td>" + billDate.Value.ToShortDateString() + "</td><td> &nbsp &nbsp &nbsp &nbsp Port:" + txtPortName.Text + " </td></tr><tr><td>Invoice No. :<td>" + txtInvoice.Text + "</td><td>&nbsp &nbsp &nbsp &nbsp MAWB NO. & DT. : " + txtMawbNo.Text + "</td></tr><tr><td>From Date:</td><td>" + billDate.Value.ToShortDateString() + "</td><td>&nbsp &nbsp &nbsp &nbsp MAWB NO. & DT. :" + txtHawbNo.Text + "</td></tr><tr><td>Date To: </td><td>" + billDate.Value.ToShortDateString() + "</td><td>&nbsp &nbsp &nbsp &nbsp BE/SB NO. & DT. : " + txtBeNo.Text + "</td></tr><tr><td>Material :</td><td>" + txtMaterial.Text + "</br>Shipper Ref. No."+txtShipperRef.Text+"</td><td>&nbsp &nbsp &nbsp &nbsp Package/Weight:" + txtPkt.Text + "/" + txtWt.Text + "</td></tr></table></div></td></tr><td colspan=\"2\">" +
                                  "<br/><div  style=\"align:left; border-radius: 5px; border: 1px solid gray;\">" +
                                  "<table style=\"font-size: 11; font-weight: bold; float:right; width:100%; height:720px; border:1px solid black; float:right\" >" +
                                  "<tr style=\"background-color: #BDDEFF \"><td>Serial No.</td><td>Taxable Under Service Tax</td><td style=\"text-align:right; margin-right:6px\">Amount</td></tr>";
            HtmlReport += "<tr><td>1.</td><td>AGENCY IS HERE</td><td style=\"text-align:right; margin-right:6px\">" + agency.ToString("N2") + "</td></tr>" + "<tr><td>2.</td><td>CHA MOT / W/L NOC</td><td style=\"text-align:right; margin-right:6px\">" + chamot.ToString("N2") + "</td></tr>" + "<tr><td>3.</td><td>GSP / DCC</td><td style=\"text-align:right; margin-right:6px\">" + gsp.ToString("N2") + "</td></tr>" + "<tr><td>4.</td><td>WT. DIFF AMT</td><td style=\"text-align:right; margin-right:6px\">" + wtdiff.ToString("N2") + "</td></tr>" + "<tr><td>5.</td><td>CUSTOM DUTY</td><td style=\"text-align:right; margin-right:6px\">" + customduty.ToString("N2") + "</td></tr>" + "<tr><td>6.</td><td>DOCUMENTATION</td><td style=\"text-align:right; margin-right:6px\">" + documentation.ToString("N2") + "</td></tr>" + "<tr><td>7.</td><td>OPEN & RE-PACKING +STRAPPING</td><td style=\"text-align:right; margin-right:6px\">" + repacking.ToString("N2") + "</td></tr>" + "<tr><td>8.</td><td>MISC CH.(APRAISING)</td><td style=\"text-align:right; margin-right:6px\">" + misc.ToString("N2") + "</td></tr>" + "<tr><td>9.</td><td>WITHOUT MARKING & LABELING</td><td style=\"text-align:right; margin-right:6px\">" + marking.ToString("N2") + "</td></tr>" + "<tr><td>10.</td><td>FORK/CRANE CH./CTG CH.</td><td style=\"text-align:right; margin-right:6px\">" + fork.ToString("N2") + "</td></tr>" + "<tr><td>11.</td><td>CMC CHA.</td><td style=\"text-align:right; margin-right:6px\">" + cmccha.ToString("N2") + "</td></tr>" + "<tr><td>12.</td><td>DCC+MINISTRY + LEAGLISATION</td><td style=\"text-align:right; margin-right:6px\">" + dcc.ToString("N2") + "</td></tr>" + "<tr><td>13.</td><td>TRANSPORTATION/LOADING/UNLOADING</td><td style=\"text-align:right; margin-right:6px\">" + loading.ToString("N2") + "</td></tr>" + "<tr style=\"background-color: #BDDEFF \"><td>Serial No.</td><td>Reimbersable</td><td style=\"text-align:right; margin-right:6px\">Amount</td></tr>" + "<tr><td>1.</td><td>AAI CH./CWC CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + aai.ToString("N2") + "</td></tr>" + "<tr><td>2.</td><td>MEASUREMENT CH.</td><td style=\"text-align:right; margin-right:6px\">" + measurment.ToString("N2") + "</td></tr>" + "<tr><td>3.</td><td>AIR FRT/SEA FRT.</td><td style=\"text-align:right; margin-right:6px\">" + airfreight.ToString("N2") + "</td></tr>" + "<tr><td>4.</td><td>BILL OF LANDING.</td><td style=\"text-align:right; margin-right:6px\">" + billoflading.ToString("N2") + "</td></tr>" + "<tr><td>5.</td><td>TR-6 CHALLN</td><td style=\"text-align:right; margin-right:6px\">" + billoflading.ToString("N2") + "</td></tr>" + "<tr><td>6.</td><td >AAI WT DIFF TC. CH.</td><td style=\"text-align:right; margin-right:6px\">" + wtdiff.ToString("N2") + "</td></tr>" + "<tr><td>7.</td><td>AAI DAMURRAGE OR PANELTY </td><td style=\"text-align:right; margin-right:6px\">" + damurrage.ToString("N2") + "</td></tr>" + "<tr><td>8.</td><td>DO CHARGES</td><td style=\"text-align:right; margin-right:6px\">" + docharges.ToString("N2") + "</td></tr>" + "<tr><td>9.</td><td>LOADING UNLOADING</td><td style=\"text-align:right; margin-right:6px\">" + loading.ToString("N2") + "</td></tr>" + "<tr><td>10.</td><td>CONTAINER OUT RECT. CH. OF YARD TO PORT & PORT TO YARD</td><td style=\"text-align:right; margin-right:6px\">" + container.ToString("N2") + "</td></tr>" + "<tr><td>11.</td><td>CHARGES RECEIVED BY AIRLINE </td><td style=\"text-align:right; margin-right:6px\">" + chargesairlines.ToString("N2") + "</td></tr>";










            HtmlReport += "</table></div><br/><div style=\"float:right; width:100% height:100%;border-radius:5px;border: 1px solid gray; margin-right:5px; margin-top:3px\"><table style=\"font-size: 11px; font-weight: bold; font-family: Helvetica;\"><tr><td>Total Taxable Amount:</td><td>" + totaltaxable.ToString("N2") + "</td></tr><tr><td>Tax %</td><td>" + taxpercent.ToString() + "%" + "</td></tr><tr><td>Total Tax: </td><td>" + taxamount.ToString("N2") + "</td></tr></tr><tr><td>Grand Taxable: </td><td>" + grandtaxable.ToString("N2") + "</td></tr><tr><td>Total Non Taxable: </td><td>" + totalnontaxable.ToString("N2") + "</td></tr><tr><td>Total Due Amount: </td><td>" + totaldue.ToString("N2") + "</td></tr></table></div></td></tr></table><br/><br/><br/><center><input type=\"button\" id=\"btnPrint\" value=\"Print\" onclick=\"printreport()\" /></center><br/></td></tr><tr><td></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">" + Methods.CompanyName + "<br/>" + Methods.CompanyContact + "<br/>" + Methods.CompanyEmail + "</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
                 "Report By: <a href=\"http://www.jnslog.com\">JNS Logistics Pvt. Ltd.</a></p></td></tr></table></div></center></body></html>";
                 
            writer.Write(HtmlReport);
            writer.Close();
            Process.Start(filename);
           // FileStream fs = File.Open("invoices/" + filename,FileMode.Open,FileAccess.Write,FileShare.None);

            */

        }

        private void txtRepacking_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAdc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLisc.Focus();
            }

        }

        private void txtLisc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAai.Focus();
            }
        }

        private void txtShipperRef_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAgency.Focus();
            }
        }
    }
}
