﻿namespace CRM
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Windows.Forms;
    public partial class CustomerRegistration : Form
    {
        public CustomerRegistration()
        {
            InitializeComponent();
        }

        private void btnRegisterCustomer_Click(object sender, EventArgs e)
        {
            if ((txtCustomerName.Text.Length > 0) && (txtContact.Text.Length >= 10))
            {
                int CustomerID = 0;
                SqlCommand comRegister = new SqlCommand("RegisterCustomer", Methods.GetConnection());
                comRegister.CommandType = CommandType.StoredProcedure;
                comRegister.Parameters.AddWithValue("@CustomerName", txtCustomerName.Text);
                comRegister.Parameters.AddWithValue("@Contact", txtContact.Text);
                comRegister.Parameters.AddWithValue("@EMail", txtEMail.Text);
                comRegister.Parameters.AddWithValue("@Address", txtAddress.Text);
                comRegister.Parameters.AddWithValue("@UserID", Methods.UserID);
                comRegister.Parameters.AddWithValue("@CustomerID", 1).Direction = ParameterDirection.Output;
                if (comRegister.ExecuteNonQuery() == 1)
                {
                    CustomerID = Convert.ToInt32(comRegister.Parameters["@CustomerID"].Value);
                    new QueryRegistration(CustomerID, txtContact.Text, txtEMail.Text).Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Registration Failed!");
                }
            }
            else
            {
                MessageBox.Show("Customer Name & Contact must be filled!", "CRM AppEx", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txtCustomerName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtContact.Focus();
            }
        }

        private void txtContact_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtEMail.Focus();
            }
        }

        private void txtEMail_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                txtAddress.Focus();
            }
        }

        private void txtAddress_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                btnRegisterCustomer.Focus();
            }
        }

    }
}
