﻿namespace CRM
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.IO;
    using System.Windows.Forms;
    public partial class SearchQuery : Form
    {
        public SearchQuery()
        {
            InitializeComponent();
        }

        private void lnkSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SearchCustomer obj = new SearchCustomer();
            obj.ShowDialog();
            txtCustomerID.Text = Methods.CustomerID.ToString();
        }

        private void txtCustomerID_TextChanged(object sender, EventArgs e)
        {
            lstQuery.Items.Clear();
            SqlCommand com = new SqlCommand("SELECT Q.QID, Q.CallDate, Q.FollowUpDate, Q.QueryID, Q.Remark, Q.CustomerID, K.QType, K.Status, C.CustomerName, C.Contact, C.Email, C.Address, K.Query, U.UserName  FROM QueryHistory Q, Customers C, Users U, Queries K  WHERE Q.CustomerID = C.CustomerID AND Q.UserID = U.UserID AND K.QID = Q.QID AND Q.CustomerID like @CustomerID ORDER BY Q.HistoryID DESC", Methods.GetConnection());
            com.Parameters.AddWithValue("@CustomerID", txtCustomerID.Text + "%");
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(com);
            adt.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                ListViewItem item = lstQuery.Items.Add(row["QID"].ToString());
                item.SubItems.Add(row["CallDate"].ToString().Substring(0, 10));
                item.SubItems.Add(row["FollowUpDate"].ToString().Substring(0, 10));
                item.SubItems.Add(row["Remark"].ToString());
                item.SubItems.Add(row["Query"].ToString());
                item.SubItems.Add(row["UserName"].ToString());
                item.SubItems.Add(row["CustomerName"].ToString());
                item.SubItems.Add(row["Contact"].ToString());
                item.SubItems.Add(row["EMail"].ToString());
                item.SubItems.Add(row["Address"].ToString());
                item.SubItems.Add(row["QueryID"].ToString());
                item.SubItems.Add(row["CustomerID"].ToString());
                item.SubItems.Add(row["QType"].ToString());
                item.SubItems.Add(row["Status"].ToString());
            }

            btnReport.Enabled = (txtCustomerID.Text.Length == 0) ? false : true;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            lstQuery.Items.Clear();
            SqlCommand com = new SqlCommand("SELECT Q.QID, Q.CallDate, Q.FollowUpDate, Q.QueryID, Q.Remark, Q.CustomerID, K.QType, K.Status, C.CustomerName, C.Contact, C.Email, C.Address, K.Query, U.UserName  FROM QueryHistory Q, Customers C, Users U, Queries K WHERE Q.CustomerID like @CustomerID AND Q.UserID = U.UserID AND K.QID = Q.QID AND Q.QID like @QueryID  ORDER BY Q.HistoryID DESC", Methods.GetConnection());
            com.Parameters.AddWithValue("@CustomerID", txtCustomerID.Text + "%");
            com.Parameters.AddWithValue("@QueryID", txtQueryID.Text + "%");
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(com);
            adt.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                ListViewItem item = lstQuery.Items.Add(row["QID"].ToString());
                item.SubItems.Add(row["CallDate"].ToString().Substring(0, 10));
                item.SubItems.Add(row["FollowUpDate"].ToString().Substring(0, 10));
                item.SubItems.Add(row["Remark"].ToString());
                item.SubItems.Add(row["Query"].ToString());
                item.SubItems.Add(row["UserName"].ToString());
                item.SubItems.Add(row["CustomerName"].ToString());
                item.SubItems.Add(row["Contact"].ToString());
                item.SubItems.Add(row["EMail"].ToString());
                item.SubItems.Add(row["Address"].ToString());
                item.SubItems.Add(row["QueryID"].ToString());
                item.SubItems.Add(row["CustomerID"].ToString());
                item.SubItems.Add(row["QType"].ToString());
                item.SubItems.Add(row["Status"].ToString());
            }
        }

        private void lstQuery_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lstQuery.SelectedItems.Count > 0)
            {
                new UpdateQuery(Convert.ToInt32(lstQuery.SelectedItems[0].SubItems[10].Text), lstQuery.SelectedItems[0].Text, Convert.ToInt32(lstQuery.SelectedItems[0].SubItems[11].Text), lstQuery.SelectedItems[0].SubItems[6].Text, lstQuery.SelectedItems[0].SubItems[4].Text, lstQuery.SelectedItems[0].SubItems[12].Text, lstQuery.SelectedItems[0].SubItems[13].Text).ShowDialog();
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            if (lstQuery.Items.Count > 0)
            {
                StreamWriter writer = new StreamWriter(new FileStream("CustomerReport.html", FileMode.Create, FileAccess.Write));
                writer.Write(GenerateReport(lstQuery.Items[0].SubItems[6].Text, lstQuery.Items[0].SubItems[7].Text, lstQuery.Items[0].SubItems[9].Text, lstQuery.Items[0].SubItems[8].Text));
                writer.Close();
                Process.Start("CustomerReport.html");
            }
        }


        string GenerateReport(string CustomerName, string Contact, string Address, string EMail)
        {
            string HtmlReport = "<html><head> <title>Customer Report</title></head><script>function printReport(){ document.getElementById(\"btnPrint\").style.display= \"none\"; window.print();}</script><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px;\">" +
                "<table width=\"100%\"><tr><td colspan=\"2\" align=\"left\"><img src=\"CRMEx-Email.png\" alt=\"CRM-AppEx\" /></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td colspan=\"2\">" +
                "<div  style=\"align:left;\">" +
                "<table style=\"width:100%; font-size: 11; font-weight: bold; \">"

                + "<tr><td align=\"right\" style=\"width:20%\">Customer Name:</td><td align=\"left\" style=\"width:80%\">" + CustomerName + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:20%\">Contact:</td><td align=\"left\" style=\"width:80%\">" + Contact + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:20%\">Address:</td><td align=\"left\" style=\"width:80%\">" + Address + "</td></tr>"
                + "<tr><td align=\"right\" style=\"width:20%\">Email:</td><td align=\"left\" style=\"width:80%\">" + EMail + "</td></tr>"
                + "</table><br/><div  style=\"align:left; border: 1px solid gray; border-radius: 5px;\">"

                + "<table style=\"width:100%; font-size: 11; font-weight: bold; \">"
                + "<tr style=\"background-color:#BDDEFF \"><td style=\"width:100px\"><b>Query ID</b></td>      <td style=\"width:100px\"><b>Call Date</b></td>      <td style=\"width:100px\"><b>Follow Up</b></td>      <td><b>Remark</b></td>      <td style=\"width:100px\"><b>User Name</b></td>      </tr>";
            foreach (ListViewItem item in lstQuery.Items)
            {
                HtmlReport += "<tr><td style=\"width:60px\">" + item.Text + "</td>      <td style=\"width: 60px\">" + item.SubItems[1].Text + "</td>      <td style=\"width:60px\">" + item.SubItems[2].Text + "</td>      <td style=\"width:200px\">" + item.SubItems[3].Text + "</td>      <td style=\"width:50px\">" + item.SubItems[6].Text + "</td>      </tr>";
            }

            HtmlReport += "</table></div><br/><center><input id=\"btnPrint\" type=\"button\" onclick=\"printReport()\" value=\"Print\" /></center><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">" + Methods.CompanyName + "<br/>" + Methods.CompanyContact + "<br/>" + Methods.CompanyEmail + "</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
            "Powered By: <a href=\"http://www.whiteapplecorp.com\">WhiteApple Software Services</a></p></td></tr></table></div></center></body></html>";

            return HtmlReport;
        }

        private void SearchQuery_Load(object sender, EventArgs e)
        {
            btnReport.Enabled = (txtCustomerID.Text.Length == 0) ? false : true;
        }

    }
}
