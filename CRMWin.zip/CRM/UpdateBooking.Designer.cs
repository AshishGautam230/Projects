﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace CRM
{

    partial class UpdateBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateBooking));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dateUpdate = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lblDestination = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblSource = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblBoy = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lnkNewStatus = new System.Windows.Forms.LinkLabel();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.ddlStatus = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAwbNo = new System.Windows.Forms.TextBox();
            this.lblEMail = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblForwardingNo = new System.Windows.Forms.Label();
            this.lblVendor = new System.Windows.Forms.Label();
            this.lblAgency = new System.Windows.Forms.LinkLabel();
            this.lblBookingDate = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPartyName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.dateUpdate);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.lblAmount);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.lblDestination);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.lblSource);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.lblBoy);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.lnkNewStatus);
            this.groupBox1.Controls.Add(this.txtRemark);
            this.groupBox1.Controls.Add(this.ddlStatus);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtAwbNo);
            this.groupBox1.Controls.Add(this.lblEMail);
            this.groupBox1.Controls.Add(this.btnUpdate);
            this.groupBox1.Controls.Add(this.lblForwardingNo);
            this.groupBox1.Controls.Add(this.lblVendor);
            this.groupBox1.Controls.Add(this.lblAgency);
            this.groupBox1.Controls.Add(this.lblBookingDate);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.lblContact);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lblPartyName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(14, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(596, 435);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter_1);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(138, 409);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(51, 17);
            this.checkBox1.TabIndex = 42;
            this.checkBox1.Text = "Alert";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // dateUpdate
            // 
            this.dateUpdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateUpdate.Location = new System.Drawing.Point(110, 203);
            this.dateUpdate.Name = "dateUpdate";
            this.dateUpdate.Size = new System.Drawing.Size(161, 22);
            this.dateUpdate.TabIndex = 40;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(68, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 41;
            this.label13.Text = "Date:";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(381, 181);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(11, 13);
            this.lblAmount.TabIndex = 39;
            this.lblAmount.Text = "-";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(323, 181);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(53, 13);
            this.label31.TabIndex = 38;
            this.label31.Text = "Amount:";
            // 
            // lblDestination
            // 
            this.lblDestination.AutoSize = true;
            this.lblDestination.Location = new System.Drawing.Point(381, 148);
            this.lblDestination.Name = "lblDestination";
            this.lblDestination.Size = new System.Drawing.Size(11, 13);
            this.lblDestination.TabIndex = 37;
            this.lblDestination.Text = "-";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(306, 148);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(70, 13);
            this.label29.TabIndex = 36;
            this.label29.Text = "Destination:";
            // 
            // lblSource
            // 
            this.lblSource.AutoSize = true;
            this.lblSource.Location = new System.Drawing.Point(381, 118);
            this.lblSource.Name = "lblSource";
            this.lblSource.Size = new System.Drawing.Size(11, 13);
            this.lblSource.TabIndex = 35;
            this.lblSource.Text = "-";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(331, 118);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 13);
            this.label27.TabIndex = 34;
            this.label27.Text = "Source:";
            // 
            // lblBoy
            // 
            this.lblBoy.AutoSize = true;
            this.lblBoy.Location = new System.Drawing.Point(107, 181);
            this.lblBoy.Name = "lblBoy";
            this.lblBoy.Size = new System.Drawing.Size(11, 13);
            this.lblBoy.TabIndex = 33;
            this.lblBoy.Text = "-";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(33, 181);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 13);
            this.label23.TabIndex = 32;
            this.label23.Text = "PickUp Boy:";
            // 
            // lnkNewStatus
            // 
            this.lnkNewStatus.AutoSize = true;
            this.lnkNewStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkNewStatus.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkNewStatus.Location = new System.Drawing.Point(482, 243);
            this.lnkNewStatus.Name = "lnkNewStatus";
            this.lnkNewStatus.Size = new System.Drawing.Size(64, 13);
            this.lnkNewStatus.TabIndex = 31;
            this.lnkNewStatus.TabStop = true;
            this.lnkNewStatus.Text = "Add Status";
            this.lnkNewStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(110, 277);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(440, 121);
            this.txtRemark.TabIndex = 30;
            // 
            // ddlStatus
            // 
            this.ddlStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStatus.FormattingEnabled = true;
            this.ddlStatus.Items.AddRange(new object[] {
            "In Transit",
            "Delivered"});
            this.ddlStatus.Location = new System.Drawing.Point(110, 239);
            this.ddlStatus.Name = "ddlStatus";
            this.ddlStatus.Size = new System.Drawing.Size(365, 21);
            this.ddlStatus.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(55, 277);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "Remark:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(62, 242);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Status:";
            // 
            // txtAwbNo
            // 
            this.txtAwbNo.Location = new System.Drawing.Point(110, 26);
            this.txtAwbNo.MaxLength = 50;
            this.txtAwbNo.Name = "txtAwbNo";
            this.txtAwbNo.Size = new System.Drawing.Size(161, 22);
            this.txtAwbNo.TabIndex = 26;
            // 
            // lblEMail
            // 
            this.lblEMail.AutoSize = true;
            this.lblEMail.Location = new System.Drawing.Point(382, 88);
            this.lblEMail.Name = "lblEMail";
            this.lblEMail.Size = new System.Drawing.Size(11, 13);
            this.lblEMail.TabIndex = 25;
            this.lblEMail.Text = "-";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(261, 404);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 26);
            this.btnUpdate.TabIndex = 24;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblForwardingNo
            // 
            this.lblForwardingNo.AutoSize = true;
            this.lblForwardingNo.Location = new System.Drawing.Point(107, 148);
            this.lblForwardingNo.Name = "lblForwardingNo";
            this.lblForwardingNo.Size = new System.Drawing.Size(11, 13);
            this.lblForwardingNo.TabIndex = 21;
            this.lblForwardingNo.Text = "-";
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Location = new System.Drawing.Point(107, 118);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(11, 13);
            this.lblVendor.TabIndex = 20;
            this.lblVendor.Text = "-";
            // 
            // lblAgency
            // 
            this.lblAgency.AutoSize = true;
            this.lblAgency.Location = new System.Drawing.Point(107, 88);
            this.lblAgency.Name = "lblAgency";
            this.lblAgency.Size = new System.Drawing.Size(11, 13);
            this.lblAgency.TabIndex = 19;
            this.lblAgency.TabStop = true;
            this.lblAgency.Text = "-";
            this.lblAgency.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblAgency_LinkClicked);
            // 
            // lblBookingDate
            // 
            this.lblBookingDate.AutoSize = true;
            this.lblBookingDate.Location = new System.Drawing.Point(107, 58);
            this.lblBookingDate.Name = "lblBookingDate";
            this.lblBookingDate.Size = new System.Drawing.Size(11, 13);
            this.lblBookingDate.TabIndex = 18;
            this.lblBookingDate.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Booking Date:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(308, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "Party Email:";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(382, 58);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(11, 13);
            this.lblContact.TabIndex = 8;
            this.lblContact.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(326, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Contact:";
            // 
            // lblPartyName
            // 
            this.lblPartyName.AutoSize = true;
            this.lblPartyName.Location = new System.Drawing.Point(382, 29);
            this.lblPartyName.Name = "lblPartyName";
            this.lblPartyName.Size = new System.Drawing.Size(11, 13);
            this.lblPartyName.TabIndex = 5;
            this.lblPartyName.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Forwarding No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Vendor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Network:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(305, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Party Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Awb No:";
            // 
            // UpdateBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(625, 448);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UpdateBooking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Booking Status";
            this.Load += new System.EventHandler(this.UpdateBooking_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        //private void InitializeComponent(string AwbNo, string PartyName, string Contact, string Email, string Vendor, string Agency, string ForwardingNo, string BookingDate, string Status)
        //{
        //    System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateBooking));
        //    this.groupBox1 = new System.Windows.Forms.GroupBox();
        //    this.lnkNewStatus = new System.Windows.Forms.LinkLabel();
        //    this.txtRemark = new System.Windows.Forms.TextBox();
        //    this.ddlStatus = new System.Windows.Forms.ComboBox();
        //    this.label10 = new System.Windows.Forms.Label();
        //    this.label9 = new System.Windows.Forms.Label();
        //    this.txtAwbNo = new System.Windows.Forms.TextBox();
        //    this.lblEMail = new System.Windows.Forms.Label();
        //    this.btnUpdate = new System.Windows.Forms.Button();
        //    this.lblForwardingNo = new System.Windows.Forms.Label();
        //    this.lblVendor = new System.Windows.Forms.Label();
        //    this.lblAgency = new System.Windows.Forms.LinkLabel();
        //    this.lblBookingDate = new System.Windows.Forms.Label();
        //    this.label8 = new System.Windows.Forms.Label();
        //    this.label14 = new System.Windows.Forms.Label();
        //    this.lblContact = new System.Windows.Forms.Label();
        //    this.label7 = new System.Windows.Forms.Label();
        //    this.lblPartyName = new System.Windows.Forms.Label();
        //    this.label5 = new System.Windows.Forms.Label();
        //    this.label4 = new System.Windows.Forms.Label();
        //    this.label3 = new System.Windows.Forms.Label();
        //    this.label2 = new System.Windows.Forms.Label();
        //    this.label1 = new System.Windows.Forms.Label();
        //    this.dateStatus = new System.Windows.Forms.DateTimePicker();
        //    this.label19 = new System.Windows.Forms.Label();
        //    this.groupBox1.SuspendLayout();
        //    this.SuspendLayout();
        //    // 
        //    // groupBox1
        //    // 
        //    this.groupBox1.Controls.Add(this.dateStatus);
        //    this.groupBox1.Controls.Add(this.label19);
        //    this.groupBox1.Controls.Add(this.lnkNewStatus);
        //    this.groupBox1.Controls.Add(this.txtRemark);
        //    this.groupBox1.Controls.Add(this.ddlStatus);
        //    this.groupBox1.Controls.Add(this.label10);
        //    this.groupBox1.Controls.Add(this.label9);
        //    this.groupBox1.Controls.Add(this.txtAwbNo);
        //    this.groupBox1.Controls.Add(this.lblEMail);
        //    this.groupBox1.Controls.Add(this.btnUpdate);
        //    this.groupBox1.Controls.Add(this.lblForwardingNo);
        //    this.groupBox1.Controls.Add(this.lblVendor);
        //    this.groupBox1.Controls.Add(this.lblAgency);
        //    this.groupBox1.Controls.Add(this.lblBookingDate);
        //    this.groupBox1.Controls.Add(this.label8);
        //    this.groupBox1.Controls.Add(this.label14);
        //    this.groupBox1.Controls.Add(this.lblContact);
        //    this.groupBox1.Controls.Add(this.label7);
        //    this.groupBox1.Controls.Add(this.lblPartyName);
        //    this.groupBox1.Controls.Add(this.label5);
        //    this.groupBox1.Controls.Add(this.label4);
        //    this.groupBox1.Controls.Add(this.label3);
        //    this.groupBox1.Controls.Add(this.label2);
        //    this.groupBox1.Controls.Add(this.label1);
        //    this.groupBox1.Location = new System.Drawing.Point(14, 10);
        //    this.groupBox1.Name = "groupBox1";
        //    this.groupBox1.Size = new System.Drawing.Size(596, 381);
        //    this.groupBox1.TabIndex = 0;
        //    this.groupBox1.TabStop = false;
        //    // 
        //    // lnkNewStatus
        //    // 
        //    this.lnkNewStatus.AutoSize = true;
        //    this.lnkNewStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
        //    this.lnkNewStatus.LinkColor = System.Drawing.Color.DodgerBlue;
        //    this.lnkNewStatus.Location = new System.Drawing.Point(482, 214);
        //    this.lnkNewStatus.Name = "lnkNewStatus";
        //    this.lnkNewStatus.Size = new System.Drawing.Size(64, 13);
        //    this.lnkNewStatus.TabIndex = 31;
        //    this.lnkNewStatus.TabStop = true;
        //    this.lnkNewStatus.Text = "Add Status";
        //    this.lnkNewStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
        //    // 
        //    // txtRemark
        //    // 
        //    this.txtRemark.Location = new System.Drawing.Point(110, 248);
        //    this.txtRemark.Multiline = true;
        //    this.txtRemark.Name = "txtRemark";
        //    this.txtRemark.Size = new System.Drawing.Size(440, 89);
        //    this.txtRemark.TabIndex = 30;
        //    // 
        //    // ddlStatus
        //    // 
        //    this.ddlStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        //    this.ddlStatus.FormattingEnabled = true;
        //    this.ddlStatus.Items.AddRange(new object[] {
        //    "In Transit",
        //    "Delivered"});
        //    this.ddlStatus.Location = new System.Drawing.Point(110, 210);
        //    this.ddlStatus.Name = "ddlStatus";
        //    this.ddlStatus.Size = new System.Drawing.Size(365, 21);
        //    this.ddlStatus.TabIndex = 29;
        //    // 
        //    // label10
        //    // 
        //    this.label10.AutoSize = true;
        //    this.label10.Location = new System.Drawing.Point(55, 248);
        //    this.label10.Name = "label10";
        //    this.label10.Size = new System.Drawing.Size(49, 13);
        //    this.label10.TabIndex = 28;
        //    this.label10.Text = "Remark:";
        //    // 
        //    // label9
        //    // 
        //    this.label9.AutoSize = true;
        //    this.label9.Location = new System.Drawing.Point(62, 213);
        //    this.label9.Name = "label9";
        //    this.label9.Size = new System.Drawing.Size(42, 13);
        //    this.label9.TabIndex = 27;
        //    this.label9.Text = "Status:";
        //    // 
        //    // txtAwbNo
        //    // 
        //    this.txtAwbNo.Location = new System.Drawing.Point(110, 26);
        //    this.txtAwbNo.MaxLength = 50;
        //    this.txtAwbNo.Name = "txtAwbNo";
        //    this.txtAwbNo.Size = new System.Drawing.Size(161, 22);
        //    this.txtAwbNo.TabIndex = 26;
        //    // 
        //    // lblEMail
        //    // 
        //    this.lblEMail.AutoSize = true;
        //    this.lblEMail.Location = new System.Drawing.Point(382, 88);
        //    this.lblEMail.Name = "lblEMail";
        //    this.lblEMail.Size = new System.Drawing.Size(11, 13);
        //    this.lblEMail.TabIndex = 25;
        //    this.lblEMail.Text = "-";
        //    // 
        //    // btnUpdate
        //    // 
        //    this.btnUpdate.Location = new System.Drawing.Point(261, 345);
        //    this.btnUpdate.Name = "btnUpdate";
        //    this.btnUpdate.Size = new System.Drawing.Size(75, 26);
        //    this.btnUpdate.TabIndex = 24;
        //    this.btnUpdate.Text = "Update";
        //    this.btnUpdate.UseVisualStyleBackColor = true;
        //    this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
        //    // 
        //    // lblForwardingNo
        //    // 
        //    this.lblForwardingNo.AutoSize = true;
        //    this.lblForwardingNo.Location = new System.Drawing.Point(107, 148);
        //    this.lblForwardingNo.Name = "lblForwardingNo";
        //    this.lblForwardingNo.Size = new System.Drawing.Size(11, 13);
        //    this.lblForwardingNo.TabIndex = 21;
        //    this.lblForwardingNo.Text = "-";
        //    // 
        //    // lblVendor
        //    // 
        //    this.lblVendor.AutoSize = true;
        //    this.lblVendor.Location = new System.Drawing.Point(107, 118);
        //    this.lblVendor.Name = "lblVendor";
        //    this.lblVendor.Size = new System.Drawing.Size(11, 13);
        //    this.lblVendor.TabIndex = 20;
        //    this.lblVendor.Text = "-";
        //    // 
        //    // lblAgency
        //    // 
        //    this.lblAgency.AutoSize = true;
        //    this.lblAgency.Location = new System.Drawing.Point(107, 88);
        //    this.lblAgency.Name = "lblAgency";
        //    this.lblAgency.Size = new System.Drawing.Size(11, 13);
        //    this.lblAgency.TabIndex = 19;
        //    this.lblAgency.TabStop = true;
        //    this.lblAgency.Text = "-";
        //    // 
        //    // lblBookingDate
        //    // 
        //    this.lblBookingDate.AutoSize = true;
        //    this.lblBookingDate.Location = new System.Drawing.Point(107, 58);
        //    this.lblBookingDate.Name = "lblBookingDate";
        //    this.lblBookingDate.Size = new System.Drawing.Size(11, 13);
        //    this.lblBookingDate.TabIndex = 18;
        //    this.lblBookingDate.Text = "-";
        //    // 
        //    // label8
        //    // 
        //    this.label8.AutoSize = true;
        //    this.label8.Location = new System.Drawing.Point(21, 58);
        //    this.label8.Name = "label8";
        //    this.label8.Size = new System.Drawing.Size(81, 13);
        //    this.label8.TabIndex = 15;
        //    this.label8.Text = "Booking Date:";
        //    // 
        //    // label14
        //    // 
        //    this.label14.AutoSize = true;
        //    this.label14.Location = new System.Drawing.Point(308, 88);
        //    this.label14.Name = "label14";
        //    this.label14.Size = new System.Drawing.Size(68, 13);
        //    this.label14.TabIndex = 10;
        //    this.label14.Text = "Party Email:";
        //    // 
        //    // lblContact
        //    // 
        //    this.lblContact.AutoSize = true;
        //    this.lblContact.Location = new System.Drawing.Point(382, 58);
        //    this.lblContact.Name = "lblContact";
        //    this.lblContact.Size = new System.Drawing.Size(11, 13);
        //    this.lblContact.TabIndex = 8;
        //    this.lblContact.Text = "-";
        //    // 
        //    // label7
        //    // 
        //    this.label7.AutoSize = true;
        //    this.label7.Location = new System.Drawing.Point(326, 58);
        //    this.label7.Name = "label7";
        //    this.label7.Size = new System.Drawing.Size(50, 13);
        //    this.label7.TabIndex = 7;
        //    this.label7.Text = "Contact:";
        //    // 
        //    // lblPartyName
        //    // 
        //    this.lblPartyName.AutoSize = true;
        //    this.lblPartyName.Location = new System.Drawing.Point(382, 29);
        //    this.lblPartyName.Name = "lblPartyName";
        //    this.lblPartyName.Size = new System.Drawing.Size(11, 13);
        //    this.lblPartyName.TabIndex = 5;
        //    this.lblPartyName.Text = "-";
        //    // 
        //    // label5
        //    // 
        //    this.label5.AutoSize = true;
        //    this.label5.Location = new System.Drawing.Point(13, 148);
        //    this.label5.Name = "label5";
        //    this.label5.Size = new System.Drawing.Size(89, 13);
        //    this.label5.TabIndex = 4;
        //    this.label5.Text = "Forwarding No:";
        //    // 
        //    // label4
        //    // 
        //    this.label4.AutoSize = true;
        //    this.label4.Location = new System.Drawing.Point(54, 118);
        //    this.label4.Name = "label4";
        //    this.label4.Size = new System.Drawing.Size(48, 13);
        //    this.label4.TabIndex = 3;
        //    this.label4.Text = "Vendor:";
        //    // 
        //    // label3
        //    // 
        //    this.label3.AutoSize = true;
        //    this.label3.Location = new System.Drawing.Point(53, 88);
        //    this.label3.Name = "label3";
        //    this.label3.Size = new System.Drawing.Size(49, 13);
        //    this.label3.TabIndex = 2;
        //    this.label3.Text = "Agency:";
        //    // 
        //    // label2
        //    // 
        //    this.label2.AutoSize = true;
        //    this.label2.Location = new System.Drawing.Point(305, 29);
        //    this.label2.Name = "label2";
        //    this.label2.Size = new System.Drawing.Size(71, 13);
        //    this.label2.TabIndex = 1;
        //    this.label2.Text = "Party Name:";
        //    // 
        //    // label1
        //    // 
        //    this.label1.AutoSize = true;
        //    this.label1.Location = new System.Drawing.Point(49, 29);
        //    this.label1.Name = "label1";
        //    this.label1.Size = new System.Drawing.Size(53, 13);
        //    this.label1.TabIndex = 0;
        //    this.label1.Text = "Awb No:";
        //    // 
        //    // dateStatus
        //    // 
        //    this.dateStatus.Format = System.Windows.Forms.DateTimePickerFormat.Short;
        //    this.dateStatus.Location = new System.Drawing.Point(110, 173);
        //    this.dateStatus.Name = "dateStatus";
        //    this.dateStatus.Size = new System.Drawing.Size(161, 22);
        //    this.dateStatus.TabIndex = 33;
        //    // 
        //    // label19
        //    // 
        //    this.label19.AutoSize = true;
        //    this.label19.Location = new System.Drawing.Point(22, 178);
        //    this.label19.Name = "label19";
        //    this.label19.Size = new System.Drawing.Size(81, 13);
        //    this.label19.TabIndex = 32;
        //    this.label19.Text = "Booking Date:";
        //    // 
        //    // UpdateBooking
        //    // 
        //    this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
        //    this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        //    this.BackColor = System.Drawing.Color.White;
        //    this.ClientSize = new System.Drawing.Size(625, 401);
        //    this.Controls.Add(this.groupBox1);
        //    this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        //    this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        //    this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        //    this.MaximizeBox = false;
        //    this.MinimizeBox = false;
        //    this.Name = "UpdateBooking";
        //    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        //    this.Text = "Update Booking Status";
        //    this.Load += new System.EventHandler(this.UpdateBooking_Load);
        //    this.groupBox1.ResumeLayout(false);
        //    this.groupBox1.PerformLayout();
        //    this.ResumeLayout(false);

        //}


       

        string AwbNo, PartyName, Contact, Email, Vendor, Agency, ForwardingNo, BookingDate, Status;
        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPartyName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblForwardingNo;
        private System.Windows.Forms.Label lblVendor;
        private System.Windows.Forms.Label lblBookingDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblEMail;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtAwbNo;
        private System.Windows.Forms.LinkLabel lnkNewStatus;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.ComboBox ddlStatus;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private LinkLabel lblAgency;
        private Label lblAmount;
        private Label label31;
        private Label lblDestination;
        private Label label29;
        private Label lblSource;
        private Label label27;
        private Label lblBoy;
        private Label label23;
        private DateTimePicker dateUpdate;
        private Label label13;
        private CheckBox checkBox1;
    }
}