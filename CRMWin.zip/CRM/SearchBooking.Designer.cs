﻿namespace CRM
{
    partial class SearchBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchBooking));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblcount = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTo = new System.Windows.Forms.DateTimePicker();
            this.dateFrom = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.ddlSearch = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstBooking = new System.Windows.Forms.ListView();
            this.AwbNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PartyName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Contact = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EMail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Weight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Vendor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Vendor_No = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Agency = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.FrowardingNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Date = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Source = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Destination = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Amount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Boy = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lblcount);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.dateTo);
            this.groupBox1.Controls.Add(this.dateFrom);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtSearch);
            this.groupBox1.Controls.Add(this.ddlSearch);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lstBooking);
            this.groupBox1.Location = new System.Drawing.Point(9, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1008, 478);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // lblcount
            // 
            this.lblcount.AutoSize = true;
            this.lblcount.ForeColor = System.Drawing.Color.Red;
            this.lblcount.Location = new System.Drawing.Point(674, 24);
            this.lblcount.Name = "lblcount";
            this.lblcount.Size = new System.Drawing.Size(36, 13);
            this.lblcount.TabIndex = 11;
            this.lblcount.Text = "Total:";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(913, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.TextChanged += new System.EventHandler(this.Delete);
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTo
            // 
            this.dateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTo.Location = new System.Drawing.Point(185, 19);
            this.dateTo.Name = "dateTo";
            this.dateTo.Size = new System.Drawing.Size(124, 22);
            this.dateTo.TabIndex = 9;
            this.dateTo.ValueChanged += new System.EventHandler(this.dateTo_ValueChanged);
            // 
            // dateFrom
            // 
            this.dateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateFrom.Location = new System.Drawing.Point(40, 19);
            this.dateFrom.Name = "dateFrom";
            this.dateFrom.Size = new System.Drawing.Size(121, 22);
            this.dateFrom.TabIndex = 8;
            this.dateFrom.ValueChanged += new System.EventHandler(this.dateFrom_ValueChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(774, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Show Booking History";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(543, 19);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(125, 22);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged_1);
            this.txtSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyUp);
            // 
            // ddlSearch
            // 
            this.ddlSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlSearch.FormattingEnabled = true;
            this.ddlSearch.Items.AddRange(new object[] {
            "AwbNo",
            "PartyName",
            "Contact",
            "EMail",
            "Vendor",
            "Agency",
            "ForwardingNo",
            "BookingDate",
            "Status",
            "Vendor_No",
            "Weight"});
            this.ddlSearch.Location = new System.Drawing.Point(406, 19);
            this.ddlSearch.Name = "ddlSearch";
            this.ddlSearch.Size = new System.Drawing.Size(122, 21);
            this.ddlSearch.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(356, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Search:";
            // 
            // lstBooking
            // 
            this.lstBooking.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstBooking.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.AwbNo,
            this.PartyName,
            this.Contact,
            this.EMail,
            this.Weight,
            this.Vendor,
            this.Vendor_No,
            this.Agency,
            this.FrowardingNo,
            this.Date,
            this.Status,
            this.Source,
            this.Destination,
            this.Amount,
            this.Boy});
            this.lstBooking.FullRowSelect = true;
            this.lstBooking.GridLines = true;
            this.lstBooking.Location = new System.Drawing.Point(3, 56);
            this.lstBooking.MultiSelect = false;
            this.lstBooking.Name = "lstBooking";
            this.lstBooking.Size = new System.Drawing.Size(1005, 419);
            this.lstBooking.TabIndex = 0;
            this.lstBooking.UseCompatibleStateImageBehavior = false;
            this.lstBooking.View = System.Windows.Forms.View.Details;
            this.lstBooking.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstBooking_MouseDoubleClick);
            // 
            // AwbNo
            // 
            this.AwbNo.Text = "AwbNo";
            this.AwbNo.Width = 120;
            // 
            // PartyName
            // 
            this.PartyName.Text = "PartyName";
            this.PartyName.Width = 150;
            // 
            // Contact
            // 
            this.Contact.Text = "Contact";
            this.Contact.Width = 100;
            // 
            // EMail
            // 
            this.EMail.Text = "EMail";
            this.EMail.Width = 100;
            // 
            // Weight
            // 
            this.Weight.Text = "Weight";
            // 
            // Vendor
            // 
            this.Vendor.Text = "Vendor";
            this.Vendor.Width = 100;
            // 
            // Vendor_No
            // 
            this.Vendor_No.Text = "Vendor No";
            this.Vendor_No.Width = 90;
            // 
            // Agency
            // 
            this.Agency.Text = "Agency";
            this.Agency.Width = 100;
            // 
            // FrowardingNo
            // 
            this.FrowardingNo.Text = "Frowarding No";
            this.FrowardingNo.Width = 103;
            // 
            // Date
            // 
            this.Date.Text = "Booking Date";
            this.Date.Width = 107;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.Width = 92;
            // 
            // Source
            // 
            this.Source.Text = "Source";
            this.Source.Width = 0;
            // 
            // Destination
            // 
            this.Destination.Text = "Destination";
            this.Destination.Width = 0;
            // 
            // Amount
            // 
            this.Amount.Text = "Amount";
            this.Amount.Width = 0;
            // 
            // Boy
            // 
            this.Boy.Text = "PickUp Boy";
            this.Boy.Width = 0;
            // 
            // fontDialog1
            // 
            this.fontDialog1.Color = System.Drawing.SystemColors.ControlText;
            // 
            // SearchBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 488);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchBooking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchBooking";
            this.Load += new System.EventHandler(this.SearchBooking_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView lstBooking;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ComboBox ddlSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader AwbNo;
        private System.Windows.Forms.ColumnHeader PartyName;
        private System.Windows.Forms.ColumnHeader Contact;
        private System.Windows.Forms.ColumnHeader EMail;
        private System.Windows.Forms.ColumnHeader Vendor;
        private System.Windows.Forms.ColumnHeader Agency;
        private System.Windows.Forms.ColumnHeader FrowardingNo;
        private System.Windows.Forms.ColumnHeader Date;
        private System.Windows.Forms.ColumnHeader Status;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColumnHeader Source;
        private System.Windows.Forms.ColumnHeader Destination;
        private System.Windows.Forms.ColumnHeader Amount;
        private System.Windows.Forms.ColumnHeader Boy;
        private System.Windows.Forms.DateTimePicker dateTo;
        private System.Windows.Forms.DateTimePicker dateFrom;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ColumnHeader Weight;
        private System.Windows.Forms.ColumnHeader Vendor_No;
        private System.Windows.Forms.Label lblcount;
    }
}