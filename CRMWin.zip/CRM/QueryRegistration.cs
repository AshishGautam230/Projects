﻿namespace CRM
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Windows.Forms;
    public partial class QueryRegistration : Form
    {
        int CustomerID;
        string Email, Contact;
        public QueryRegistration()
        {
            InitializeComponent();
        }

        public QueryRegistration(int CustomerID, string Contact, string Email)
        {
            InitializeComponent();
            this.CustomerID = CustomerID;
            lblCustomerID.Text = CustomerID.ToString();
            this.Email = Email;
            this.Contact = Contact;
            lnkSearch.Visible = false;
        }

        private void QueryRegistration_Load(object sender, EventArgs e)
        {
            ddlResolution.SelectedIndex = 1;
            ddlQueryType.SelectedIndex = 0;
        }

        private void btnRegisterQuery_Click(object sender, EventArgs e)
        {
            string QID = string.Empty;
            switch (ddlQueryType.SelectedIndex)
            {
                //Google, JD-INTL, JD-DHL,JD-FedEx, JD-BD, Informer, Walking, Relation, Sulekha, Others
                case 0:
                    QID = "GO-";
                    break;
                case 1:
                    QID = "JDINTL-";
                    break;
                case 2:
                    QID = "JDDHL-";
                    break;
                case 3:
                    QID = "JDFDX-";
                    break;
                case 4:
                    QID = "JDBD-";
                    break;
                case 5:
                    QID = "INFO-";
                    break;
                case 6:
                    QID = "WALK-";
                    break;
                case 7:
                    QID = "REL-";
                    break;
                case 8:
                    QID = "SUL-";
                    break;
                default:
                    QID = "OTH-";
                    break;
            }
            SqlCommand com = new SqlCommand("RegisterQuery", Methods.GetConnection());
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@QType", ddlQueryType.Text);
            com.Parameters.AddWithValue("@CustomerID", this.CustomerID);
            com.Parameters.AddWithValue("@Query", txtQuery.Text);
            com.Parameters.AddWithValue("@Status", ddlResolution.Text);
            com.Parameters.AddWithValue("@FollowUPDate", dateFollowUp.Value.ToShortDateString());
            com.Parameters.AddWithValue("@Remark", "Query Received : " + txtRemark.Text);
            com.Parameters.AddWithValue("@UserID", Methods.UserID);
            com.Parameters.AddWithValue("@QID", QID);
            com.Parameters.AddWithValue("@QueryID", 1).Direction = ParameterDirection.Output;
            com.Parameters.AddWithValue("@QIDOUT", "").Direction = ParameterDirection.Output;
            int QueryID = 0;
            string QueryRef = "";
            if (com.ExecuteNonQuery() > 0)
            {
                QueryID = Convert.ToInt32(com.Parameters["@QueryID"].Value);
                QueryRef = com.Parameters["@QIDOUT"].Value.ToString();
            }
            // SEND SMS & EMAIL

            if (chkEMail.Checked)
            {
                List<string> To = new List<string>();
                To.Add(Email);
                MessageBox.Show(Email);
                EmailAPI.Email obj = new EmailAPI.Email("mail.whiteapplecorp.com", 0, false, true, To, "query@whiteapplecorp.com", "India#123#", "Query Received", "<center><div style=\"border: 1px solid #DBDBDB; border-radius: 5px; padding: 10px; width: 600px; text-align: left;\"><img src=\"http://www.whiteapplecorp.com/CRMEx-Email.png\"><br/><br/>Dear User,<br/><br/>Thanks for your query!<br/><br/>Your Customer ID is: <b>" + CustomerID.ToString() + "</b> and your Reference ID is: <b>" + QueryRef + "</b><br/>Thanks,<br/>" + Methods.CompanyName + "</div></center>", true, "Customer Relationship Management");
                obj.SendEmail();
            }
            this.Close();
        }

        private void lnkSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new SearchCustomer().ShowDialog();
            lblCustomerID.Text = Methods.CustomerID.ToString();
            this.CustomerID = Methods.CustomerID;
            this.Email = Methods.CustomerEmail;
        }
    }
}
