﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace CRM
{
    public partial class SearchBooking : Form
    {
        string userid = Methods.UserID.ToString();
        
        
        public SearchBooking()
        {
            InitializeComponent();
        }

        private void SearchBooking_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(userid);
            if (userid.Equals("1"))
            {
                button2.Enabled = true;
            }
            ddlSearch.SelectedIndex = 0;
            lstBooking.Items.Clear();
            SqlCommand com = new SqlCommand("SELECT * FROM Booking where bookingdate=@bookingdate", Methods.GetConnection());
            com.Parameters.AddWithValue("@bookingdate", DateTime.Now.ToShortDateString());
            SqlDataReader reader = com.ExecuteReader();

            while (reader.Read())
            {
                ListViewItem item = lstBooking.Items.Add(reader["AwbNo"].ToString());
                item.SubItems.Add(reader["PartyName"].ToString());
                item.SubItems.Add(reader["Contact"].ToString());
                item.SubItems.Add(reader["EMail"].ToString());
                item.SubItems.Add(reader["weight"].ToString());
                item.SubItems.Add(reader["Vendor"].ToString());
                item.SubItems.Add(reader["vendor_no"].ToString());
                item.SubItems.Add(reader["Agency"].ToString());                
                item.SubItems.Add(reader["ForwardingNo"].ToString());
                item.SubItems.Add(reader["BookingDate"].ToString().Substring(0, 10));
                item.SubItems.Add(reader["Status"].ToString());
                item.SubItems.Add(reader["Source"].ToString());
                item.SubItems.Add(reader["Destination"].ToString());
                item.SubItems.Add(reader["Amount"].ToString());
                item.SubItems.Add(reader["PickUpBoy"].ToString());
            }
            lblcount.Text ="Total: "+ lstBooking.Items.Count.ToString();
            reader.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            datasearch();
        }

        public void datasearch()
        {

            string dfrom = dateFrom.Value.ToShortDateString();
            string dto = dateTo.Value.ToShortDateString();
            //MessageBox.Show(dfrom + " " + dto);
            SqlCommand com = new SqlCommand("SELECT * FROM Booking WHERE "+ddlSearch.Text+" like '%" + txtSearch.Text + "%'" + " and BookingDate between @dfrom and @dto ", Methods.GetConnection());
            //com.Parameters.AddWithValue("@column", ddlSearch.Text.Trim());
            // com.Parameters.AddWithValue("@value", txtSearch.Text.Trim());
            com.Parameters.AddWithValue("@dfrom", dfrom);
            com.Parameters.AddWithValue("@dto", dto);
            SqlDataReader reader = com.ExecuteReader();
            lstBooking.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = lstBooking.Items.Add(reader["AwbNo"].ToString());
                item.SubItems.Add(reader["PartyName"].ToString());
                item.SubItems.Add(reader["Contact"].ToString());
                item.SubItems.Add(reader["EMail"].ToString());
                item.SubItems.Add(reader["weight"].ToString());
                item.SubItems.Add(reader["Vendor"].ToString());
                item.SubItems.Add(reader["vendor_no"].ToString());
                item.SubItems.Add(reader["Agency"].ToString());
                item.SubItems.Add(reader["ForwardingNo"].ToString());
                item.SubItems.Add(reader["BookingDate"].ToString().Substring(0, 10));
                item.SubItems.Add(reader["Status"].ToString());
                item.SubItems.Add(reader["Source"].ToString());
                item.SubItems.Add(reader["Destination"].ToString());
                item.SubItems.Add(reader["Amount"].ToString());
                item.SubItems.Add(reader["PickUpBoy"].ToString());
            }
            lblcount.Text ="Total: "+ lstBooking.Items.Count.ToString();
            reader.Close();
        }


        private void lstBooking_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lstBooking.SelectedItems.Count > 0)
            {
              //  new UpdateBooking(lstBooking.SelectedItems[0].Text, lstBooking.SelectedItems[0].SubItems[1].Text, lstBooking.SelectedItems[0].SubItems[2].Text, lstBooking.SelectedItems[0].SubItems[3].Text, lstBooking.SelectedItems[0].SubItems[5].Text, lstBooking.SelectedItems[0].SubItems[5].Text, lstBooking.SelectedItems[0].SubItems[7].Text, lstBooking.SelectedItems[0].SubItems[7].Text, lstBooking.SelectedItems[0].SubItems[8].Text, lstBooking.SelectedItems[0].SubItems[9].Text, lstBooking.SelectedItems[0].SubItems[10].Text, lstBooking.SelectedItems[0].SubItems[11].Text, lstBooking.SelectedItems[0].SubItems[12].Text).ShowDialog();
                new UpdateBooking(lstBooking.SelectedItems[0].Text, lstBooking.SelectedItems[0].SubItems[1].Text, lstBooking.SelectedItems[0].SubItems[2].Text, lstBooking.SelectedItems[0].SubItems[3].Text, lstBooking.SelectedItems[0].SubItems[5].Text, lstBooking.SelectedItems[0].SubItems[7].Text, lstBooking.SelectedItems[0].SubItems[8].Text, lstBooking.SelectedItems[0].SubItems[9].Text, lstBooking.SelectedItems[0].SubItems[10].Text, lstBooking.SelectedItems[0].SubItems[11].Text, lstBooking.SelectedItems[0].SubItems[12].Text, lstBooking.SelectedItems[0].SubItems[13].Text, lstBooking.SelectedItems[0].SubItems[14].Text).ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lstBooking.SelectedItems.Count > 0)
            {
                StreamWriter writer = new StreamWriter(new FileStream("BookingReport.html", FileMode.Create, FileAccess.Write));
                writer.Write(GenerateReport(lstBooking.SelectedItems[0].Text, GetURL(lstBooking.SelectedItems[0].SubItems[7].Text,lstBooking.SelectedItems[0].SubItems[8].Text.ToUpper())));
                writer.Close();
                Process.Start("BookingReport.html");
            }
        }

        string GetURL(string Agency, string AwbNo)
        {
            string URL = "";
            switch (Agency.ToUpper())
            {
                case "DHL":
                    URL = "http://www.dhl.co.in/en/express/tracking.html?AWB=" + AwbNo;
                    break;
                case "FEDEX":
                    URL = "http://www.fedex.com/Tracking?clienttype=dotcom&initial=n&ascend_header=1&sum=n&cntry_code=us&language=english&tracknumber_list=" + AwbNo;
                    break;
                case "ARAMEX":
                    URL = "http://www.aramex.com/track_results_multiple.aspx?ShipmentNumber=" + AwbNo;
                    break;
                case "TNT":
                    URL = "http://www.tnt.com/webtracker/tracking.do#" + AwbNo;
                    break;
                case "UPS":
                    URL = "http://wwwapps.ups.com/WebTracking/track?HTMLVersion=5.0&loc=en_IN&Requester=UPSHome&WBPM_lid=homepage%2Fct1.html_pnl_trk&trackNums=" + AwbNo;
                    break;
                case "UBX":
                    URL = "http://www.ubxpress.in/TrackDetails.asp?afno=" + AwbNo;
                    break;
            }
            return URL;
        }

        string GenerateReport(string AwbNo, string URL)
        {
            string HtmlReport = "<html><head> <title>Booking History Report</title></head><script>function printReport(){ document.getElementById(\"btnPrint\").style.display= \"none\"; window.print();}</script><body style=\"background-color: #959595; font-size: small;\"><center><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 900px;\">" +
                "<table width=\"100%\"><tr><td colspan=\"2\" align=\"left\"><img src=\"CRMEx-Email.png\" alt=\"CRM-AppEx\" /></td></tr><tr><td colspan=\"2\"><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td colspan=\"2\">" +
                "<div  style=\"align:left;\">" +
                "<table style=\"width:100%; font-size: 11; font-weight: bold; \">" +
                "<tr><td align=\"right\" style=\"width:20%\">Party Name:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[1].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Contact:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[2].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">EMail:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[3].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Vendor:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[4].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Agency:</td><td align=\"left\" style=\"width:80%\"><a href=\""+URL+"\">" + lstBooking.SelectedItems[0].SubItems[7].Text + "</a></td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Forwarding No:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[8].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Booking Date:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[9].Text + "</td></tr>" +
                "<tr><td align=\"right\" style=\"width:20%\">Status:</td><td align=\"left\" style=\"width:80%\">" + lstBooking.SelectedItems[0].SubItems[10].Text + "</td></tr></table>"+
                "<br/><div  style=\"align:left; border: 1px solid #EDEDED; border-radius: 5px;\"><table style=\"width:100%; font-size: 11; font-weight: bold; \">";

            SqlCommand com = new SqlCommand("SELECT TrackingDate, Remark FROM BookingHistory WHERE AwbNo = @AwbNo", Methods.GetConnection());
            com.Parameters.AddWithValue("@AwbNo", AwbNo);
            SqlDataReader reader = com.ExecuteReader();
            HtmlReport += "<tr style=\"background-color: #BDDEFF;\"><td style=\"width:30%\">Tracking Date:</td><td style=\"width:40%\">Remark</td></tr>";
            while (reader.Read())
            {
                HtmlReport += "<tr><td style=\"width:30%\">" + reader[0].ToString().Substring(0, 10) + "</td><td style=\"width:70%\">" + reader[1].ToString() + "</td></tr>";
            }
            reader.Close();
            HtmlReport += "</table></div>";

            HtmlReport += "<br/><center><input id=\"btnPrint\" type=\"button\" onclick=\"printReport()\" value=\"Print\" /></center><div style=\"background-color:#6AAEFA; height: 10px;\" /></td></tr><tr><td align=\"left\" style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-left: 10px;\">" + Methods.CompanyName + "<br/>" + Methods.CompanyContact + "<br/>" + Methods.CompanyEmail + "</p></td><td align=\"right\"  style=\"width: 50%\"><p style=\"font-size: x-small; font-weight: bold; padding-right: 10px;\">" +
            "Powered By: <a href=\"http://www.web4world.biz\">Websoft</a></p></td></tr></table></div></center></body></html>";

            return HtmlReport;
        }

        private void dateTo_ValueChanged(object sender, EventArgs e)
        {
            datasearch();
        }

        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                datasearch();
            }
        }

        private void Delete(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (lstBooking.SelectedItems.Count > 0)
            {
                string awbno = lstBooking.SelectedItems[0].SubItems[0].Text;
                if (MessageBox.Show("Are you sure about deleting AWB No."+awbno+" ? Click Yes, else click No","CRM AppEx", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    SqlCommand deletecmd = new SqlCommand("delete from booking where awbno=@awbno",Methods.GetConnection());
                    SqlCommand deletebookinghistory = new SqlCommand("delete from bookinghistory where awbno=@awbno", Methods.GetConnection());
                    deletebookinghistory.Parameters.AddWithValue("@awbno", awbno);

                    deletecmd.Parameters.AddWithValue("@awbno", awbno);
                    deletecmd.ExecuteNonQuery();
                    deletebookinghistory.ExecuteNonQuery();
                    datasearch();

                    
                }
            }
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dateFrom_ValueChanged(object sender, EventArgs e)
        {
            datasearch();
        }
    }
}
