﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CRM
{
    public partial class CompanyDetails : Form
    {
        public CompanyDetails()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            {
                SqlCommand com = new SqlCommand("TRUNCATE TABLE CompanyInfo", Methods.GetConnection());
                com.ExecuteNonQuery();
            }
            {
                SqlCommand com = new SqlCommand("TRUNCATE TABLE CompanyInfo; INSERT INTO CompanyInfo (CompanyName, Contact, EMail) VALUES (@CompanyName, @Contact, @EMail)", Methods.GetConnection());
                com.Parameters.AddWithValue("@CompanyName", txtCompany.Text);
                com.Parameters.AddWithValue("@Contact", txtContact.Text);
                com.Parameters.AddWithValue("@EMail", txtEMail.Text);
                com.ExecuteNonQuery();
                MessageBox.Show("Details saved!");
                this.Close();
            }
        }

        private void CompanyDetails_Load(object sender, EventArgs e)
        {
            
            SqlCommand com = new SqlCommand("SELECT CompanyName, Contact, EMail FROM CompanyInfo", Methods.GetConnection());
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                txtCompany.Text = reader[0].ToString();
                txtContact.Text = reader[1].ToString();
                txtEMail.Text = reader[2].ToString();
            }
            reader.Close();
        }
    }
}
