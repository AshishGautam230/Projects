﻿namespace CRM
{
    partial class BookingEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookingEntry));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtvendorawb = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtweight = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPartyName = new System.Windows.Forms.ComboBox();
            this.dlqtype = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtconsignee = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dateBooking = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtForwardingNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPartyEmail = new System.Windows.Forms.TextBox();
            this.ddlNetwork = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkVendor = new System.Windows.Forms.LinkLabel();
            this.lnkNetwork = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.ddlVendor = new System.Windows.Forms.ComboBox();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPartyContact = new System.Windows.Forms.TextBox();
            this.lnkPickUpBoy = new System.Windows.Forms.LinkLabel();
            this.ddlPickupBoy = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lnkStatus = new System.Windows.Forms.LinkLabel();
            this.ddlStatus = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAwnNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnInsert = new System.Windows.Forms.Button();
            this.chkalert = new System.Windows.Forms.CheckBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.txtpkg = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtpkg);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtvendorawb);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtweight);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtPartyName);
            this.groupBox1.Controls.Add(this.dlqtype);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtconsignee);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtAmount);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtDestination);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.dateBooking);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtForwardingNo);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtPartyEmail);
            this.groupBox1.Controls.Add(this.ddlNetwork);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lnkVendor);
            this.groupBox1.Controls.Add(this.lnkNetwork);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.ddlVendor);
            this.groupBox1.Controls.Add(this.txtSource);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtPartyContact);
            this.groupBox1.Controls.Add(this.lnkPickUpBoy);
            this.groupBox1.Controls.Add(this.ddlPickupBoy);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtRemark);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lnkStatus);
            this.groupBox1.Controls.Add(this.ddlStatus);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtAwnNo);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(11, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(904, 392);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtvendorawb
            // 
            this.txtvendorawb.Location = new System.Drawing.Point(546, 129);
            this.txtvendorawb.MaxLength = 150;
            this.txtvendorawb.Name = "txtvendorawb";
            this.txtvendorawb.Size = new System.Drawing.Size(330, 22);
            this.txtvendorawb.TabIndex = 59;
            this.txtvendorawb.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtvendorawb_KeyUp);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(463, 134);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 13);
            this.label18.TabIndex = 58;
            this.label18.Text = "Vendor AWB:";
            // 
            // txtweight
            // 
            this.txtweight.Location = new System.Drawing.Point(114, 335);
            this.txtweight.MaxLength = 150;
            this.txtweight.Name = "txtweight";
            this.txtweight.Size = new System.Drawing.Size(94, 22);
            this.txtweight.TabIndex = 56;
            this.txtweight.TextChanged += new System.EventHandler(this.txtweight_TextChanged);
            this.txtweight.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtweight_KeyUp);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(40, 338);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 13);
            this.label17.TabIndex = 57;
            this.label17.Text = "Weight/KG:";
            // 
            // txtPartyName
            // 
            this.txtPartyName.AllowDrop = true;
            this.txtPartyName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPartyName.FormattingEnabled = true;
            this.txtPartyName.Location = new System.Drawing.Point(114, 60);
            this.txtPartyName.Name = "txtPartyName";
            this.txtPartyName.Size = new System.Drawing.Size(307, 21);
            this.txtPartyName.TabIndex = 55;
            this.txtPartyName.SelectedIndexChanged += new System.EventHandler(this.txtPartyName_SelectedIndexChanged);
            this.txtPartyName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPartyName_KeyUp_1);
            // 
            // dlqtype
            // 
            this.dlqtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dlqtype.FormattingEnabled = true;
            this.dlqtype.Items.AddRange(new object[] {
            "Google",
            "Sulekha",
            "Website",
            "Justdial",
            "Reference",
            "Others"});
            this.dlqtype.Location = new System.Drawing.Point(547, 287);
            this.dlqtype.Name = "dlqtype";
            this.dlqtype.Size = new System.Drawing.Size(265, 21);
            this.dlqtype.TabIndex = 54;
            this.dlqtype.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            this.dlqtype.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dlqtype_KeyUp);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(471, 291);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 53;
            this.label16.Text = "Query Type:";
            // 
            // txtconsignee
            // 
            this.txtconsignee.Location = new System.Drawing.Point(114, 249);
            this.txtconsignee.MaxLength = 150;
            this.txtconsignee.Name = "txtconsignee";
            this.txtconsignee.Size = new System.Drawing.Size(307, 22);
            this.txtconsignee.TabIndex = 52;
            this.txtconsignee.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtconsignee_KeyUp);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(39, 252);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 13);
            this.label15.TabIndex = 51;
            this.label15.Text = "Congignee:";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(114, 291);
            this.txtAmount.MaxLength = 150;
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(307, 22);
            this.txtAmount.TabIndex = 49;
            this.txtAmount.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAmount_KeyUp);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(53, 294);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 50;
            this.label13.Text = "Amount:";
            // 
            // txtDestination
            // 
            this.txtDestination.Location = new System.Drawing.Point(114, 207);
            this.txtDestination.MaxLength = 150;
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(307, 22);
            this.txtDestination.TabIndex = 6;
            this.txtDestination.TextChanged += new System.EventHandler(this.txtDestination_TextChanged);
            this.txtDestination.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDestination_KeyUp);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 212);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 13);
            this.label14.TabIndex = 48;
            this.label14.Text = "Destination:";
            // 
            // dateBooking
            // 
            this.dateBooking.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateBooking.Location = new System.Drawing.Point(547, 22);
            this.dateBooking.Name = "dateBooking";
            this.dateBooking.Size = new System.Drawing.Size(330, 22);
            this.dateBooking.TabIndex = 7;
            this.dateBooking.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dateBooking_KeyUp);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(459, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Booking Date:";
            // 
            // txtForwardingNo
            // 
            this.txtForwardingNo.Location = new System.Drawing.Point(547, 59);
            this.txtForwardingNo.MaxLength = 150;
            this.txtForwardingNo.Name = "txtForwardingNo";
            this.txtForwardingNo.Size = new System.Drawing.Size(330, 22);
            this.txtForwardingNo.TabIndex = 8;
            this.txtForwardingNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtForwardingNo_KeyUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(451, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Forwarding No:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(492, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Vendor:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Party Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(485, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Network:";
            // 
            // txtPartyEmail
            // 
            this.txtPartyEmail.Location = new System.Drawing.Point(114, 96);
            this.txtPartyEmail.MaxLength = 150;
            this.txtPartyEmail.Name = "txtPartyEmail";
            this.txtPartyEmail.Size = new System.Drawing.Size(307, 22);
            this.txtPartyEmail.TabIndex = 3;
            this.txtPartyEmail.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPartyEmail_KeyUp);
            // 
            // ddlNetwork
            // 
            this.ddlNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlNetwork.FormattingEnabled = true;
            this.ddlNetwork.Items.AddRange(new object[] {
            "ARAMEX",
            "DHL",
            "FEDEX",
            "TNT",
            "UBX",
            "UPS"});
            this.ddlNetwork.Location = new System.Drawing.Point(547, 165);
            this.ddlNetwork.Name = "ddlNetwork";
            this.ddlNetwork.Size = new System.Drawing.Size(265, 21);
            this.ddlNetwork.TabIndex = 10;
            this.ddlNetwork.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ddlNetwork_KeyUp);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Party Email:";
            // 
            // lnkVendor
            // 
            this.lnkVendor.AutoSize = true;
            this.lnkVendor.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkVendor.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkVendor.Location = new System.Drawing.Point(823, 101);
            this.lnkVendor.Name = "lnkVendor";
            this.lnkVendor.Size = new System.Drawing.Size(56, 13);
            this.lnkVendor.TabIndex = 15;
            this.lnkVendor.TabStop = true;
            this.lnkVendor.Text = "Add New";
            this.lnkVendor.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkVendor_LinkClicked);
            // 
            // lnkNetwork
            // 
            this.lnkNetwork.AutoSize = true;
            this.lnkNetwork.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkNetwork.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkNetwork.Location = new System.Drawing.Point(821, 167);
            this.lnkNetwork.Name = "lnkNetwork";
            this.lnkNetwork.Size = new System.Drawing.Size(56, 13);
            this.lnkNetwork.TabIndex = 16;
            this.lnkNetwork.TabStop = true;
            this.lnkNetwork.Text = "Add New";
            this.lnkNetwork.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkNetwork_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Party Contact:";
            // 
            // ddlVendor
            // 
            this.ddlVendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlVendor.FormattingEnabled = true;
            this.ddlVendor.Location = new System.Drawing.Point(547, 97);
            this.ddlVendor.Name = "ddlVendor";
            this.ddlVendor.Size = new System.Drawing.Size(265, 21);
            this.ddlVendor.TabIndex = 9;
            this.ddlVendor.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ddlVendor_KeyUp);
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(114, 170);
            this.txtSource.MaxLength = 150;
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(307, 22);
            this.txtSource.TabIndex = 5;
            this.txtSource.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSource_KeyUp);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(61, 175);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 44;
            this.label12.Text = "Source:";
            // 
            // txtPartyContact
            // 
            this.txtPartyContact.Location = new System.Drawing.Point(114, 133);
            this.txtPartyContact.MaxLength = 12;
            this.txtPartyContact.Name = "txtPartyContact";
            this.txtPartyContact.Size = new System.Drawing.Size(307, 22);
            this.txtPartyContact.TabIndex = 4;
            this.txtPartyContact.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPartyContact_KeyUp);
            // 
            // lnkPickUpBoy
            // 
            this.lnkPickUpBoy.AutoSize = true;
            this.lnkPickUpBoy.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkPickUpBoy.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkPickUpBoy.Location = new System.Drawing.Point(823, 207);
            this.lnkPickUpBoy.Name = "lnkPickUpBoy";
            this.lnkPickUpBoy.Size = new System.Drawing.Size(56, 13);
            this.lnkPickUpBoy.TabIndex = 17;
            this.lnkPickUpBoy.TabStop = true;
            this.lnkPickUpBoy.Text = "Add New";
            this.lnkPickUpBoy.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkPickUpBoy_LinkClicked);
            // 
            // ddlPickupBoy
            // 
            this.ddlPickupBoy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPickupBoy.FormattingEnabled = true;
            this.ddlPickupBoy.Location = new System.Drawing.Point(547, 204);
            this.ddlPickupBoy.Name = "ddlPickupBoy";
            this.ddlPickupBoy.Size = new System.Drawing.Size(265, 21);
            this.ddlPickupBoy.TabIndex = 11;
            this.ddlPickupBoy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ddlPickupBoy_KeyUp);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(467, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 37;
            this.label11.Text = "Pick-Up Boy:";
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(547, 333);
            this.txtRemark.MaxLength = 250;
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(330, 33);
            this.txtRemark.TabIndex = 13;
            this.txtRemark.Text = "Shipment information received.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(491, 333);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Remark:";
            // 
            // lnkStatus
            // 
            this.lnkStatus.AutoSize = true;
            this.lnkStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkStatus.LinkColor = System.Drawing.Color.DodgerBlue;
            this.lnkStatus.Location = new System.Drawing.Point(821, 247);
            this.lnkStatus.Name = "lnkStatus";
            this.lnkStatus.Size = new System.Drawing.Size(64, 13);
            this.lnkStatus.TabIndex = 18;
            this.lnkStatus.TabStop = true;
            this.lnkStatus.Text = "Add Status";
            this.lnkStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkStatus_LinkClicked);
            // 
            // ddlStatus
            // 
            this.ddlStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlStatus.FormattingEnabled = true;
            this.ddlStatus.Items.AddRange(new object[] {
            "In Transit",
            "Delivered"});
            this.ddlStatus.Location = new System.Drawing.Point(547, 244);
            this.ddlStatus.Name = "ddlStatus";
            this.ddlStatus.Size = new System.Drawing.Size(265, 21);
            this.ddlStatus.TabIndex = 12;
            this.ddlStatus.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ddlStatus_KeyUp);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(498, 247);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Status:";
            // 
            // txtAwnNo
            // 
            this.txtAwnNo.Location = new System.Drawing.Point(114, 22);
            this.txtAwnNo.MaxLength = 50;
            this.txtAwnNo.Name = "txtAwnNo";
            this.txtAwnNo.Size = new System.Drawing.Size(307, 22);
            this.txtAwnNo.TabIndex = 1;
            this.txtAwnNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAwnNo_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Awb No:";
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(424, 406);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(87, 27);
            this.btnInsert.TabIndex = 14;
            this.btnInsert.Text = "&Submit";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // chkalert
            // 
            this.chkalert.AutoSize = true;
            this.chkalert.Location = new System.Drawing.Point(305, 412);
            this.chkalert.Name = "chkalert";
            this.chkalert.Size = new System.Drawing.Size(51, 17);
            this.chkalert.TabIndex = 16;
            this.chkalert.Text = "&Alert";
            this.chkalert.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Enabled = false;
            this.btnUpdate.Location = new System.Drawing.Point(540, 406);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(87, 27);
            this.btnUpdate.TabIndex = 17;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(224, 338);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 13);
            this.label19.TabIndex = 60;
            this.label19.Text = "No. of PKG";
            // 
            // txtpkg
            // 
            this.txtpkg.Location = new System.Drawing.Point(298, 333);
            this.txtpkg.MaxLength = 150;
            this.txtpkg.Name = "txtpkg";
            this.txtpkg.Size = new System.Drawing.Size(123, 22);
            this.txtpkg.TabIndex = 61;
            this.txtpkg.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtpkg_KeyUp);
            // 
            // BookingEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(926, 454);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.chkalert);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BookingEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Booking Entry";
            this.Load += new System.EventHandler(this.BookingEntry_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateBooking;
        private System.Windows.Forms.TextBox txtForwardingNo;
        private System.Windows.Forms.TextBox txtPartyContact;
        private System.Windows.Forms.TextBox txtAwnNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.ComboBox ddlNetwork;
        private System.Windows.Forms.LinkLabel lnkStatus;
        private System.Windows.Forms.ComboBox ddlStatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel lnkNetwork;
        private System.Windows.Forms.LinkLabel lnkVendor;
        private System.Windows.Forms.LinkLabel lnkPickUpBoy;
        private System.Windows.Forms.ComboBox ddlPickupBoy;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ddlVendor;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtPartyEmail;
        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtconsignee;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox dlqtype;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox chkalert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ComboBox txtPartyName;
        private System.Windows.Forms.TextBox txtweight;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtvendorawb;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtpkg;
        private System.Windows.Forms.Label label19;
    }
}