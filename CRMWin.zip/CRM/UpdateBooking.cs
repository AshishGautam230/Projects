﻿namespace CRM
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Windows.Forms;
    using System.Diagnostics;
    using System.Net;
    using System.Net.Mail;
    using System.IO;
    
    public partial class UpdateBooking : Form
    {

        public UpdateBooking()
        {
            InitializeComponent();
        }

        public UpdateBooking(string AwbNo, string PartyName, string Contact, string Email,string Vendor,string Agency, string ForwardingNo, string BookingDate, string Status, string Source, string Destination, string Amount, string Boy)
        {
            InitializeComponent();
            this.AwbNo = txtAwbNo.Text = AwbNo;
            this.PartyName = lblPartyName.Text = PartyName;
            this.Contact = lblContact.Text = Contact;
            this.Email = lblEMail.Text = Email;
            this.Vendor = lblVendor.Text = Vendor;
            this.Agency = lblAgency.Text = Agency;
            this.ForwardingNo = lblForwardingNo.Text = ForwardingNo;
            this.BookingDate = lblBookingDate.Text = BookingDate;
            this.Status = ddlStatus.Text = Status;
            lblBoy.Text = Boy;
            lblSource.Text = Source;
            lblDestination.Text = Destination;
            lblAmount.Text = Amount;
        }

        private void UpdateBooking_Load(object sender, EventArgs e)
        {
            {
                SqlCommand com = new SqlCommand("SELECT Status FROM BookingStatus", Methods.GetConnection());
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ddlStatus.Items.Add(reader["Status"].ToString());
                }
                reader.Close();
                if (ddlStatus.Items.Count > 0)
                {
                    ddlStatus.SelectedIndex = 0;
                }
            }
            ddlStatus.Text = this.Status;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlCommand com = new SqlCommand("UpdateBookingStatus", Methods.GetConnection());
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@AwbNo", this.AwbNo);
            com.Parameters.AddWithValue("@Status", ddlStatus.Text);
            com.Parameters.AddWithValue("@Remark", txtRemark.Text);
            com.Parameters.AddWithValue("@UserID", Methods.UserID);
            com.Parameters.AddWithValue("@TDate", dateUpdate.Text);
            com.ExecuteNonQuery();
            if (ddlStatus.Text == "Delivered")
            {
                bookingemailnsms(txtAwbNo.Text, lblEMail.Text, lblContact.Text, lblSource.Text, lblDestination.Text, lblForwardingNo.Text, lblAgency.Text);
                
            }
            MessageBox.Show("Status Updated!");

            this.Close();

        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string status = Microsoft.VisualBasic.Interaction.InputBox("Enter new status:", "CRM AppEx", "");
            if (!string.IsNullOrEmpty(status))
            {
                SqlCommand com = new SqlCommand("INSERT INTO BookingStatus (Status) VALUES (@Status)", Methods.GetConnection());
                com.Parameters.AddWithValue("@Status", status);
                com.ExecuteNonQuery();
                ddlStatus.Items.Add(status);
            }
        }

        private void lblAgency_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string URL = "";
            switch (lblAgency.Text.ToUpper())
            {
                case "DHL":
                    URL = "http://www.dhl.com/cgi-bin/tracking.pl?TID=CP_IND&FIRST_DB=&awb=" + lblForwardingNo.Text.ToString();
                    break;
                case "FEDEX":
                    URL = "http://www.fedex.com/Tracking?clienttype=dotcom&initial=n&ascend_header=1&sum=n&cntry_code=us&language=english&tracknumber_list=" +lblForwardingNo.Text.ToString();
                    break;
                case "ARAMEX":
                    URL = "http://www.aramex.com/track_results_multiple.aspx?ShipmentNumber=" +lblForwardingNo.Text.ToString();
                    break;
                case "TNT":
                    URL = "http://www.tnt.com/webtracker/tracking.do#" + lblForwardingNo.Text.ToString();
                    break;
                case "UPS":
                    URL = "http://wwwapps.ups.com/WebTracking/track?HTMLVersion=5.0&loc=en_IN&Requester=UPSHome&WBPM_lid=homepage%2Fct1.html_pnl_trk&trackNums=" + lblForwardingNo.Text.ToString();
                    break;
                case "UBX":
                    URL = "http://www.ubxpress.in/TrackDetails.asp?afno=" + lblForwardingNo.Text.ToString();
                    break;
            }
            if (URL.Length > 0)
            {
                Process.Start(URL);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }
        public void bookingemailnsms(string awbno, string partyemail, string partyphone, string source, string destination, string fwdno, string network)
        {
            string url = Methods.trackurl(network, fwdno);
            string formatdate = dateUpdate.Text;

            string message = "<html><body><div style=\"border:1px solid #DDDDDD; border-radius: 5px; font-family: Helvetica; background-color: #ffffff; width: 700px; margin-left:10px\">" + "<p style=\"margin-left:10px;\"><img src=\"http://www.globalindiaexpress.com/images/gie-logo.jpg\" height=60 width=200></img><br><br>Dear Customer,<br>Greetings from Global India Express.<br>Your shipment with<strong> Global India Express AWB No.: - " + awbno + "</strong> to Destination: <strong>" + destination + "</strong> with Forwarding Network:<strong> " + network + "</strong> Forwarding Number: <strong>" + fwdno + "</strong> has been delivered on " + formatdate + ".<br>To track the status of your shipment please <a href=" + url + ">click here</a>.<br><br>If you have any further questions, please feel free to call our Customer Support Team on 011-41785200  or write us to info@globalindiaexpress.com.<br><br>We thank you for choosing <strong>Global India Express</strong> for your shipping requirements.<br><br>Customer Support Team<br>Global India Express.<br>L341, Street No. 1,<br>Mahipalpur Extension,<br>New Delhi, 110037.<br><a href=www.globalindiaexparess.com>www.globalindiaexpress.com</a> </p></div></body></html>";

                       SmtpClient smtpClient = new SmtpClient("smtp.gmail.com",587);
            //smtpClient.Host = "smtp.gmail.com";
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = true;
            smtpClient.Credentials = new System.Net.NetworkCredential("support@globalindiaexpress.com", "India#123#");

            MailMessage mlmsg = new MailMessage();
            mlmsg.From = new MailAddress("support@globalindiaexpress.com", "Global India Express");

            mlmsg.To.Add(new MailAddress(partyemail));
            mlmsg.Subject = "Global India Express: Shipment Status Reference: " + awbno;
            mlmsg.IsBodyHtml = true;
            mlmsg.Body = message;
            if (partyemail.Length >= 4)
            {
                smtpClient.Send(mlmsg);
            }


            mlmsg.To.Add(new MailAddress(partyemail));
            //mlmsg.Subject = "Shipment Delivery Notification " + awbno;
            mlmsg.IsBodyHtml = true;
            mlmsg.Body = message;
            smtpClient.Send(mlmsg);

            //   string smsapi = "http://sms.smsbazar.co.in/rao/trans_sms.php?loginid=amit&password=123456789&sender_id=BALAJI&to=" + partyphone + "&message=Your shipment with GIE AWB No." + awbno + "to "+destination+" has been forwarded by "+network+" with AWB No. "+fwdno+". Queries, dial 011-41785200.";
            //            string smsapi=	http://trx.orangesms.in/api/sendmsg.php?user=averma81&pass=123&sender=BALAJI&phone=&to=" + partyphone + "&message=Your shipment with GIE AWB No." + awbno + "to "+destination+" has been forwarded by "+network+" with AWB No. "+fwdno+". Queries, dial 011-41785200.";

            string smsapi = "http://trx.orangesms.net/api/sendmsg.php?user=averma81&pass=123&sender=GLOBAL&phone=" + partyphone + "&text=Your shipment with GLOBAL Awb No." + awbno + " to " + destination + " with " + network + " , AWB No. " + fwdno + " has been delivered on " + dateUpdate.Text + " with "+txtRemark.Text+". For any queries call 011-41785200." + "&priority=ndnd&stype=normal";

            WebRequest request = HttpWebRequest.Create(smsapi);
            WebResponse response = request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need 
            // Response.Write(urlText.ToString());
            




        }

        private void lblAgency_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }

}
